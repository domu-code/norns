# Verification record

- Environment: Linux, JDK 21; no Android SDK, Gradle, emulator, or outbound artifact download access.
- `javac`: `GridState.java`, `WavIO.java`, `MidiStreamParser.java` compiled successfully.
- JDK smoke test: series-monome output frame (`0x80` + 8 data bytes), threshold, 8×8 paging, 16-bit stereo WAV round-trip, and MIDI running-status/realtime/split messages passed.
- Lua 5.4 parser/runtime smoke tests: `bootstrap.lua` and all four demo scripts parsed, and each demo `init()` completed with stubbed host functions. Actual LuaJ/Android execution remains unverified.
- Android APK generation and physical-device test: **not run**. Full Gradle build and Android API compilation remain to verify.
- Core audio, USB FTDI, Android MIDI and OSC code requires runtime testing. Script compatibility extends only to implemented API subset.

## Suggested first physical-device validation

1. Build debug APK via GitHub Actions (workflow supplied) or Android Studio.
2. Install and load `04_Sample_Deck.lua`. Confirm the sample plays and E2 controls rate.
3. Connect headphones. Enable mic, load `02_Tape_Garden.lua`, record for a few seconds and play back.
4. Plug in a USB MIDI device, select MIDI SCAN, trigger MIDI monitor and MIDI output from `01_Pocket_Grid.lua`.
5. Connect original FTDI series monome and press MONOME USB. Verify all eight columns/rows and both pages. If rotated, use ROT.
6. Exercise USB keyboard F1/F2/F3, Q/W/E, A/S/D, G mappings.
7. Import a standalone third-party `.lua` file and log any unsupported module or syntax error for the compatibility backlog.
