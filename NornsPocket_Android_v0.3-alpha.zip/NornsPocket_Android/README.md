# NORNS / POCKET

**Android norns-style runtime, v0.3.0-alpha. Source project.**

This Android Studio project provides a genuine on-device Lua script host with virtual norns controls, a 128×64 drawing surface, a 16×8 grid, FTDI serial support for an original **series** monome 64, Android MIDI and OSC connectivity, and a self-contained six-voice, two-buffer sampler/looper. It does **not** depend on an existing norns unit or a Raspberry Pi.

It is a **compatibility implementation**, not a full port of the original norns operating system. The original norns SuperCollider engines are not included. Existing scripts will work to the extent that their APIs are covered, and some Lua 5.3 syntax will need conversion because this build uses LuaJ 3.0.1.

## Getting an APK

**Option A: Android Studio (Windows/macOS/Linux).**

1. Extract this entire folder.
2. Open `NornsPocket_Android` as a project in Android Studio.
3. Allow Gradle sync to fetch the Android Gradle Plugin 8.6.1 and `org.luaj:luaj-jse:3.0.1` from Maven Central. Use **Gradle 8.7, JDK 17, Android SDK 35**. If Android Studio asks for a local Gradle distribution because the wrapper JAR is not bundled, choose Gradle 8.7.
4. Connect an Android device with developer options and USB debugging, or build **Build > Build APK(s)**.
5. The unsigned-for-distribution, debug-signed installable APK appears at `app/build/outputs/apk/debug/app-debug.apk` once the build succeeds.

**Option B: GitHub Actions (no Android Studio installation).**

1. Put the complete folder contents at the root of a new GitHub repository.
2. Open the repository's **Actions** tab and run **Build debug APK** (or push to `main`).
3. When the workflow completes successfully, download the `NornsPocket-debug-apk` artifact. The APK inside is a debug build for sideloading.

The APK **has not been built or tested on a real Android device in this delivery**, because the source-generating environment did not have an Android SDK/Gradle installation or external build-network access. The GitHub build workflow is supplied for convenient verification.

## Included functions

| Part | Implemented | Notes |
| --- | --- | --- |
| 128×64 screen | Yes | `clear`, `level`, `move`, `line`, `rect`, `circle`, `arc`, `text`, alignment, `fill`, `stroke`, `update` |
| K1/K2/K3, E1/E2/E3 | Yes | Touch and physical USB/Bluetooth keyboard |
| Lua scripts | Partial norns compatibility | LuaJ 3.0.1, not norns' Lua 5.3 runtime |
| Script import | Yes | Android file picker, app-local `.lua` directory |
| Virtual grid | Yes | 16×8, 16 LED intensities, multitouch not implemented |
| Original monome 64 | Driver written, hardware test pending | FTDI, series 2007–2010 protocol, 8×8 pages, rotate, LED brightness threshold |
| USB MIDI | Android interface implemented, hardware test pending | Duplex port 1, multiple detected Android devices, raw MIDI events |
| OSC UDP | Yes | Sends OSC 1.0, receives on UDP 10111 |
| Clock and metro | Yes, basic | Nonblocking scheduled Lua coroutines and timers, BPM/sync |
| `params` and `controlspec` | Basic | Numeric/control/option/binary/trigger/file/text, actions and persistence |
| `util`, `musicutil`, `tabutil` | Basic functions | Not the complete original libraries |
| Two audio buffers | Yes | 60 seconds each, mono float internally, 48 kHz |
| Six Softcut-like voices | Core | Loop, rate (including reverse), position, pan, gain, live input, record/overdub, crossfade, buffer read/write, phase/position polling |
| WAV read/write | Yes | PCM 8/16/24/32 bit and float 32; 1/2 channels, resampling on import |
| Live microphone | Yes, subject to permission and device audio support | Mono 48k capture, selectable on UI |
| Synth engine | Minimal | Built-in sine-percussion oscillator for `engine.hz`/`engine.note_on` demonstrations |
| Original SuperCollider engines | **No** | `engine.name = 'PolyPerc'` does **not** instantiate PolyPerc |
| Full Softcut filters/routing | **No** | Extended pre/post filtering and voice-to-voice routing remain to port |

## Included scripts

- `01_Pocket_Grid.lua`: 8-track, 16-step polymetric sequencer. Grid editing, rate/length editing, MIDI notes and internal audio.
- `02_Tape_Garden.lua`: 4-second starting-length microphone loop/overdub instrument with rate, length and feedback control.
- `03_MIDI_Monitor.lua`: MIDI notes/CC display and a sound on incoming note-on events.
- `04_Sample_Deck.lua`: imports the bundled `factory_loop.wav` into Softcut and plays/varispeeds it.

The first launch installs these scripts, plus the automatically generated sample in the app's private file storage. Imported `.wav` files are placed under `_path.audio`, e.g. `_path.audio .. "my_sample.wav"`.

## Hardware usage

**Monome 64:** Attach using a USB OTG or powered USB-C hub, tap **MONOME USB**, and grant the Android USB permission prompt. Only devices with FTDI vendor ID `0x0403` are probed. The low-level implementation targets the vintage series protocol (USB serial at 115200 baud, `0x80` eight-row LED frames and `0x00`/`0x10` button reports). That is **not** the same as the 2005 `40h` protocol or a modern USB MIDI grid. Device-specific handshake and physical orientation must be verified using the actual unit.

The virtual grid always displays 16 columns and 8 rows. **64 PAGE A/B** chooses which half is mirrored on the physical 8×8 grid. **LED ≥1/4/8/12** collapses brightness values to binary physical on/off. **ROT** adjusts physical orientation.

**USB MIDI:** Connect any Android-compatible USB MIDI class-compliant device and tap **MIDI SCAN**. `midi.connect(1)` refers to Android's first successfully opened device in the current scan. Output is sent through its device input port; incoming data arrives through its output port. Some devices expose multiple ports; this initial implementation opens port index zero per direction. MIDI clock events may be transmitted from scripts.

**Keyboard mapping:** F1/F2/F3 = K1/K2/K3 held; Q/W/E = E1/E2/E3 clockwise, A/S/D = counterclockwise; G = toggle physical monome grid page. Use an OTG hub for keyboard, monome and USB MIDI simultaneously.

**Recording:** Tap **MIC OFF** to request microphone permission and start AudioRecord capture, then open `02_Tape_Garden`. K2 toggles recording/overdubbing; K3 toggles monitoring/playback. **Use headphones** when recording to avoid acoustic feedback.

## Source tree

```text
app/src/main/java/io/oll/nornspocket/
    MainActivity.java       UI, import, keyboard, USB/MIDI controls
    LuaRuntime.java         LuaJ host and native API bindings
    Screen128.java          Monochrome framebuffer and drawing API
    GridState.java          16x8 virtual grid, 8x8 physical translation
    MonomeSerial.java       Raw FTDI vintage series-monome USB driver
    MidiBridge.java         Android MIDI bridge
    MidiStreamParser.java   Running-status / realtime message splitter
    OscBridge.java          OSC/UDP network bridge
    SoftcutAudio.java       PCM audio, two buffers, six voices, capture
    WavIO.java              RIFF WAV decoder/encoder
app/src/main/assets/lua/bootstrap.lua
app/src/main/assets/scripts/*.lua
app/src/test/java/io/oll/nornspocket/*.java
.github/workflows/build-apk.yml
```

## API and compatibility limitations

- This uses **LuaJ** (Lua 5.2-compatible subset) for an APK with no native compilation. Scripts relying on Lua 5.3 integer/bitwise operators or native Lua modules can fail to parse. The long-term full-compatibility path is a bundled native Lua 5.3 VM and an expanded original API shim.
- `screen` is a subset of norns' graphics API. Fonts, clipping, transformation, blends, and custom screens are not complete.
- `softcut` is a separate Java implementation. It has the core operations needed for sample playback, recording, reverse, looping and overdubbing; it does **not** replicate the original filters, routing matrices, exact smoothing, transient handling, or timing guarantees. Phase callbacks are UI-rate (~20 Hz), not DSP-sample-accurate.
- Recording depends on the device's actual audio input and Android permission. Low-latency performance and buffer underruns have not been measured on real hardware. The audio backend currently uses `AudioTrack`, rather than Oboe/AAudio.
- Full norns menu, the Maiden editor, `crow`, `arc`, SuperCollider engines, external Lua/C modules, and a complete norns `dust` folder hierarchy are not included. Bundled demos require no additional libraries.
- OSC is basic int/float/string/boolean; no bundles, time tags, blobs or proper peer-address callbacks.
- The monome driver is grounded in the published **series** protocol, but must be tested against the user's particular hardware and Android USB host implementation.
- Scripts imported from the internet run in the app's Android sandbox; Java reflection and OS execute have been disabled, but untrusted scripts can still access app-local files and trigger MIDI, microphone and network capabilities. Only import scripts you trust.

## Testing

A JUnit test suite checks the monome series output bytes, WAV PCM import/export, and MIDI stream parsing. The portable `GridState`, `WavIO`, and `MidiStreamParser` classes were compiled with JDK 21 and exercised successfully outside Android. Bundled Lua scripts parsed and their initialization routines executed under a Lua 5.4 smoke-test interpreter with mocked hardware calls; this does not substitute for an on-device LuaJ test. Run the full Android unit test suite with:

```bash
gradle :app:testDebugUnitTest
```

Run `gradle :app:assembleDebug` or the GitHub workflow to validate the full Android compile. **Neither full Android compilation nor actual device tests were possible in this environment.**

## Attribution

Independent norns-compatible experiment. **Not an official monome/norns release**, and not endorsed by monome. Hardware protocol information is documented by the monome community and libmonome. The project uses `org.luaj:luaj-jse:3.0.1` under its respective licence; dependency licences should be reviewed before redistributing a binary. No norns GPL code or SuperCollider DSP source has been copied into the deliverable.

Relevant specifications: https://monome.org/docs/norns/reference/ · https://monome.org/docs/norns/api/modules/softcut.html · https://github.com/monome/libmonome/tree/main/src/proto
