-- MIDI MONITOR: receives Android MIDI, forwards incoming notes as sine tones.
local m=midi.connect(1)
local count=0
local message='none yet'
function redraw()
  screen.clear();screen.level(15);screen.move(0,10);screen.text('MIDI MONITOR')
  screen.level(7);screen.move(0,26);screen.text('MESSAGES  '..count)
  screen.move(0,41);screen.text(message)
  screen.level(3);screen.move(0,60);screen.text('Connect USB MIDI + RESCAN');screen.update()
end
m.event=function(data)
  local msg=midi.to_msg(data);count=count+1
  if msg.type=='note_on' then
    message='NOTE '..msg.note..' VEL '..msg.vel
    if msg.vel>0 then engine.hz(musicutil.note_num_to_freq(msg.note)) end
  elseif msg.type=='cc' then message='CC '..msg.cc..' = '..msg.val
  else message=msg.type end
  redraw()
end
function init() redraw() end
