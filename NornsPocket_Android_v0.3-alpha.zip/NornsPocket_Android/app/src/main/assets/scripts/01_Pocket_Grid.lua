-- POCKET GRID: 8-track polymetric monome sequencer, MIDI + internal tone.
local g=grid.connect(1)
local out=midi.connect(1)
local notes={36,38,42,46,48,50,56,60}
local steps, lengths={},{}
local bpm=118
local playhead=1
local playing=true
local selected=1
for y=1,8 do steps[y]={};lengths[y]=16;for x=1,16 do steps[y][x]=(y==1 and x%4==1) or (y==2 and x%4==3) or (y==3 and x%2==1) end end
local function refresh_grid()
  g:all(0)
  for y=1,8 do for x=1,16 do
    local l=steps[y][x] and 11 or 0
    if x==playhead then l=steps[y][x] and 15 or 3 end
    if x>lengths[y] then l=0 end
    g:led(x,y,l)
  end end
  g:refresh()
end
function redraw()
  screen.clear();screen.level(15);screen.move(0,9);screen.text('POCKET GRID  /  8 TRACKS')
  screen.level(7);screen.move(0,21);screen.text('BPM '..bpm..'   STEP '..playhead)
  screen.move(0,33);screen.text('ROW '..selected..'  LEN '..lengths[selected])
  screen.move(0,45);screen.text(playing and 'RUNNING' or 'STOPPED')
  screen.level(4);screen.move(0,60);screen.text('K2 RUN  K3 RESET  E3 LEN');screen.update()
end
function key(n,z)
  if z~=1 then return end
  if n==2 then playing=not playing end
  if n==3 then playhead=1 end
  redraw();refresh_grid()
end
function enc(n,d)
  if n==1 then bpm=util.clamp(bpm+d,30,260);clock.set_tempo(bpm)
  elseif n==2 then selected=util.clamp(selected+d,1,8)
  elseif n==3 then lengths[selected]=util.clamp(lengths[selected]+d,1,16) end
  redraw();refresh_grid()
end
g.key=function(x,y,z)
  if z==1 then steps[y][x]=not steps[y][x];selected=y;redraw();refresh_grid() end
end
function init()
  clock.set_tempo(bpm);refresh_grid();redraw()
  clock.run(function()
    while true do
      clock.sync(0.25)
      if playing then
        for row=1,8 do
          local s=((playhead-1)%lengths[row])+1
          if steps[row][s] then
            out:note_on(notes[row],105,10)
            engine.hz(musicutil.note_num_to_freq(notes[row]+24))
            local note=notes[row]
            clock.run(function() clock.sleep(.08);out:note_off(note,0,10) end)
          end
        end
        playhead=playhead%16+1
        refresh_grid();redraw()
      end
    end
  end)
end
