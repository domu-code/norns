-- TAPE GARDEN: softcut-style 4-second varispeed mic looper.
-- Tap MIC in the toolbar and allow the microphone before pressing K2.
local g=grid.connect(1)
local duration=4
local rate=1
local feedback=.65
local isRec=false
local isPlaying=false
local clip=1
local phase=0
local function lights()
  g:all(0)
  for x=1,16 do
    g:led(x,1,x/16<=phase and 12 or 2)
    g:led(x,3,isPlaying and 5 or 0)
    g:led(x,5,isRec and 15 or 0)
  end
  g:refresh()
end
function redraw()
  screen.clear();screen.level(15);screen.move(0,9);screen.text('TAPE GARDEN  /  SOFTCUT')
  screen.level(10);screen.move(0,23);screen.text('SPEED  '..string.format('%.2f',rate)..'x')
  screen.move(0,34);screen.text('OVERDUB '..string.format('%.2f',feedback))
  screen.level(15);screen.move(0,46);screen.text((isRec and 'REC ') or '----')
  screen.move(39,46);screen.text(isPlaying and 'PLAY' or 'STOP')
  screen.level(4);screen.move(0,61);screen.text('K2 REC  K3 PLAY  E2 RATE');screen.update()
end
function init()
  softcut.buffer_clear()
  softcut.enable(clip,1)
  softcut.buffer(clip,1)
  softcut.loop(clip,1)
  softcut.loop_start(clip,0)
  softcut.loop_end(clip,duration)
  softcut.position(clip,0)
  softcut.fade_time(clip,.025)
  softcut.level(clip,1)
  softcut.rec_level(clip,1)
  softcut.pre_level(clip,feedback)
  softcut.level_input_cut(1,clip,1)
  softcut.level_input_cut(2,clip,0)
  lights();redraw()
  local timer=metro.init(function()
    phase=(softcut_position or 0)/duration
    lights();redraw()
  end,.1,-1)
  softcut.event_position(function(n,p) softcut_position=p end)
  timer.event=function()
    softcut.query_position(1)
    phase=(softcut_position or 0)/duration
    lights();redraw()
  end
  timer:start()
end
function key(n,z)
  if z~=1 then return end
  if n==2 then isRec=not isRec;softcut.rec(clip,isRec and 1 or 0)
  elseif n==3 then isPlaying=not isPlaying;softcut.play(clip,isPlaying and 1 or 0) end
  lights();redraw()
end
function enc(n,d)
  if n==1 then duration=util.clamp(duration+d*.25,.5,30);softcut.loop_end(clip,duration)
  elseif n==2 then rate=util.clamp(rate+d*.05,-2,2);softcut.rate(clip,rate)
  elseif n==3 then feedback=util.clamp(feedback+d*.025,0,1);softcut.pre_level(clip,feedback) end
  redraw()
end
