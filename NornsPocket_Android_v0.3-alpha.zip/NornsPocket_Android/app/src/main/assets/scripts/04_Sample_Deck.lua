-- SAMPLE DECK: factory WAV loaded into Android Softcut, variable speed and trim.
local path=_path.audio..'factory_loop.wav'
local g=grid.connect(1)
local rate=1
local loopEnd=2
local playing=true
local phase=0
function grid_leds()
  g:all(0)
  for x=1,16 do g:led(x,1,x<=math.floor(phase*16) and 15 or 2) end
  for x=1,16 do g:led(x,4,playing and 7 or 1) end
  g:refresh()
end
function redraw()
  screen.clear();screen.level(15);screen.move(0,10);screen.text('SAMPLE DECK / WAV PLAYBACK')
  screen.move(0,25);screen.text('RATE   '..string.format('%.2f',rate)..'x')
  screen.level(8);screen.move(0,39);screen.text('LENGTH '..string.format('%.2f',loopEnd)..'s')
  screen.move(0,52);screen.text(playing and 'PLAY' or 'PAUSE')
  screen.level(3);screen.move(0,63);screen.text('K2 PLAY  E2 RATE  E3 END');screen.update()
end
function init()
  softcut.buffer_clear()
  softcut.buffer_read_mono(path,0,0,-1,1,1)
  softcut.enable(1,1);softcut.buffer(1,1)
  softcut.loop(1,1);softcut.loop_start(1,0);softcut.loop_end(1,2)
  softcut.fade_time(1,.015);softcut.rate(1,1)
  softcut.level(1,1);softcut.position(1,0);softcut.play(1,1)
  softcut.event_position(function(i,p) phase=p/loopEnd end)
  local ticker=metro.init(function() softcut.query_position(1);grid_leds();redraw() end,.08,-1)
  ticker:start()
  grid_leds();redraw()
end
function key(n,z)
  if n==2 and z==1 then playing=not playing;softcut.play(1,playing and 1 or 0);redraw() end
  if n==3 and z==1 then softcut.position(1,0) end
end
function enc(n,d)
  if n==2 then rate=util.clamp(rate+d*.05,-2,2);softcut.rate(1,rate) end
  if n==3 then loopEnd=util.clamp(loopEnd+d*.05,.25,2);softcut.loop_end(1,loopEnd) end
  redraw()
end
