-- Norns Pocket compatibility shim. Runs with LuaJ 3.0.1 (Lua 5.2-ish), not Lua 5.3.
-- Host implements drawing, MIDI, OSC, sample buffers, USB devices and scheduling.

function include(p) return __host.include(p) end
function init() end
function redraw() end
function enc(n,d) end
function key(n,z) end
function cleanup() end

util = {}
function util.clamp(x,lo,hi) return math.max(lo,math.min(hi,x)) end
function util.round(n,places) local m=10^(places or 0); return math.floor(n*m+.5)/m end
function util.linlin(a,b,c,d,x) if b==a then return c end; return c+(d-c)*(x-a)/(b-a) end
function util.linexp(a,b,c,d,x) if b==a or c<=0 or d<=0 then return c end; return c*(d/c)^((x-a)/(b-a)) end
function util.explin(a,b,c,d,x) if a<=0 or b<=0 or a==b then return c end; return c+(d-c)*math.log(x/a)/math.log(b/a) end
function util.expexp(a,b,c,d,x) if a<=0 or b<=0 or c<=0 or d<=0 or a==b then return c end; return c*(d/c)^(math.log(x/a)/math.log(b/a)) end
function util.wrap(x,lo,hi) return ((x-lo)%(hi-lo+1))+lo end
function util.time() return __host.seconds() end
function util.dbamp(db) return 10^(db/20) end
function util.ampdb(amp) return 20*math.log(amp)/math.log(10) end
package.preload["util"] = function() return util end

musicutil = {}
local names={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"}
function musicutil.note_num_to_freq(n) return 440*2^((n-69)/12) end
function musicutil.freq_to_note_num(f) return 69+12*math.log(f/440)/math.log(2) end
function musicutil.note_num_to_name(n,include_octave) local index=math.floor(n); local result=names[index%12+1]; if include_octave then return result..tostring(math.floor(index/12)-1) end; return result end
function musicutil.generate_scale_of_length(root,mode,length) local intervals={2,2,1,2,2,2,1}; local output={root}; for i=2,length do output[i]=output[i-1]+intervals[((i-2)%7)+1] end; return output end
package.preload["musicutil"] = function() return musicutil end

tabutil = {}
function tabutil.contains(t,needle) for _,v in pairs(t) do if v==needle then return true end end return false end
function tabutil.count(t) local n=0; for _ in pairs(t) do n=n+1 end; return n end
function tabutil.keys(t) local a={}; for k in pairs(t) do a[#a+1]=k end; return a end
package.preload["tabutil"] = function() return tabutil end

controlspec = {}
function controlspec.new(min,max,warp,step,default,units,quantum)
  return {minval=min,maxval=max,warp=warp or "lin",step=step or 0,default=default or min,units=units or "",quantum=quantum or 0}
end
setmetatable(controlspec,{__call=function(_,...) return controlspec.new(...) end})
controlspec.UNIPOLAR=controlspec.new(0,1,"lin",0,.5)
controlspec.BIPOLAR=controlspec.new(-1,1,"lin",0,0)
package.preload["controlspec"] = function() return controlspec end

params = {items={},order={},name="script"}
local function add_param(self,id,name,kind,value,low,high,step,options)
  local p={id=id,name=name or id,kind=kind,value=value,low=low,high=high,step=step,options=options,action=nil}
  self.items[id]=p;self.order[#self.order+1]=id;return p
end
function params:clear() self.items={};self.order={} end
function params:lookup_param(id) return self.items[id] or self.items[self.order[id]] end
function params:add_number(id,name,minimum,maximum,default,formatter)
  add_param(self,id,name,"number",default or minimum,minimum,maximum,1)
end
function params:add_control(id,name,spec,formatter)
  add_param(self,id,name,"control",spec.default or spec.minval,spec.minval,spec.maxval,spec.step)
end
function params:add_option(id,name,options,default)
  add_param(self,id,name,"option",default or 1,1,#options,1,options)
end
function params:add_binary(id,name,behavior,default)
  add_param(self,id,name,"binary",default or 0,0,1,1)
end
function params:add_trigger(id,name) add_param(self,id,name,"trigger",0,0,1,1) end
function params:add_file(id,name,path) add_param(self,id,name,"file",path or "") end
function params:add_text(id,name,default) add_param(self,id,name,"text",default or "") end
function params:add_separator(id,name) add_param(self,id,name or id,"separator",nil) end
function params:add_group(id,name,n) add_param(self,id,name or id,"group",nil) end
function params:add(t)
  local typ=t.type or "number"
  if typ=="control" then return self:add_control(t.id,t.name,t.controlspec or controlspec.new(t.min or 0,t.max or 1,"lin",0,t.default or 0)) end
  if typ=="option" then return self:add_option(t.id,t.name,t.options,t.default) end
  if typ=="binary" then return self:add_binary(t.id,t.name,t.behavior,t.default) end
  if typ=="trigger" then return self:add_trigger(t.id,t.name) end
  return self:add_number(t.id,t.name,t.min or 0,t.max or 127,t.default)
end
function params:get(id) local p=self:lookup_param(id);return p and p.value end
function params:set(id,value,silent)
  local p=self:lookup_param(id);if not p then return end
  if type(value)=="number" and p.low and p.high then
    value=util.clamp(value,p.low,p.high)
    if p.kind=="number" or p.kind=="option" or p.kind=="binary" then value=math.floor(value+.5) end
  end
  p.value=value;if p.action and not silent then p.action(value) end
end
function params:delta(id,d)
  local p=self:lookup_param(id);if not p or type(p.value)~="number" then return end
  self:set(id,p.value+d*((p.step and p.step>0) and p.step or ((p.high-p.low)/100)))
end
function params:string(id)
  local p=self:lookup_param(id);if not p then return "" end
  if p.options then return tostring(p.options[p.value]) end
  if type(p.value)=="number" then return string.format("%.2f",p.value) end
  return tostring(p.value)
end
function params:set_action(id,func) local p=self:lookup_param(id);if p then p.action=func end end
function params:bang(id)
  if id then local p=self:lookup_param(id); if p and p.action then p.action(p.value) end; return end
  for _,pid in ipairs(self.order) do local p=self.items[pid];if p and p.action then p.action(p.value) end end
end
function params:hide(id) end
function params:show(id) end
function params:rebuild() end
function params:write(path)
  local f=io.open(path or (_path.data.."params.txt"),"w")
  if not f then return end
  for _,pid in ipairs(self.order) do local p=self.items[pid]; if type(p.value)=="number" then f:write(pid,"=",p.value,"\n") end end
  f:close()
end
function params:read(path)
  local f=io.open(path or (_path.data.."params.txt"),"r");if not f then return end
  for line in f:lines() do local id,val=line:match("^([^=]+)=(.*)$");if id then self:set(id,tonumber(val) or val) end end
  f:close()
end

-- Norns grid is 1-based in Lua, 16x8 virtual and physically paged 8x8.
grid = {device={},vports={}}
function grid.connect(port)
  local g={rows=8,cols=16,port=port or 1,device=true}
  function g:led(x,y,l) __host.grid_set(x,y,l) end
  function g:all(level) __host.grid_all(level or 0) end
  function g:refresh() __host.grid_refresh() end
  function g:rotation(r) end
  function g:key(x,y,z) end
  grid.device[g.port]=g
  return g
end
function grid.cleanup() grid.device={} end
function __grid_key(x,y,z) for _,g in pairs(grid.device) do if type(g.key)=="function" then g.key(x,y,z) end end end

midi = {device={},vports={}}
local function midi_device(port)
  local m={port=port,event=function(data) end}
  function m:send(bytes) __host.midi_send(self.port,bytes) end
  function m:note_on(note,velocity,channel) self:send({0x90+((channel or 1)-1),note,velocity or 100}) end
  function m:note_off(note,velocity,channel) self:send({0x80+((channel or 1)-1),note,velocity or 0}) end
  function m:cc(cc,val,channel) self:send({0xB0+((channel or 1)-1),cc,val}) end
  function m:program_change(n,channel) self:send({0xC0+((channel or 1)-1),n}) end
  function m:pitchbend(value,channel) local v=math.floor(value or 8192);self:send({0xE0+((channel or 1)-1),v%128,math.floor(v/128)%128}) end
  function m:clock() self:send({0xF8}) end
  function m:start() self:send({0xFA}) end
  function m:stop() self:send({0xFC}) end
  return m
end
function midi.connect(n) n=n or 1; midi.device[n]=midi.device[n] or midi_device(n);return midi.device[n] end
function midi.to_msg(data)
  local status=data[1] or 0; local typ=math.floor(status/16)*16
  if typ==0x90 then return {type="note_on",note=data[2],vel=data[3],ch=status%16+1} end
  if typ==0x80 then return {type="note_off",note=data[2],vel=data[3],ch=status%16+1} end
  if typ==0xB0 then return {type="cc",cc=data[2],val=data[3],ch=status%16+1} end
  if status==0xF8 then return {type="clock"} end
  return {type="other",data=data}
end
function __midi_event(port,bytes) local m=midi.device[port];if m and m.event then m.event(bytes) end end
function midi.cleanup() midi.device={} end

-- The host timer is on the Lua HandlerThread. Coroutines yield non-blockingly.
clock = {tempo=120,transport={start=function() end,stop=function() end}}
local clocks={};local clockId=0;local epoch=util.time()
function clock.get_tempo() return clock.tempo end
function clock.set_tempo(bpm) clock.tempo=math.max(1,bpm) end
function clock.get_beat_sec() return 60/clock.tempo end
function clock.get_beats() return (util.time()-epoch)/clock.get_beat_sec() end
local function clock_resume(id,...)
  local task=clocks[id];if not task or task.cancelled then return end
  local ok,wake=coroutine.resume(task.co,...)
  if not ok then clocks[id]=nil;__host.status("clock #"..id..": "..tostring(wake));return end
  if coroutine.status(task.co)=="dead" then clocks[id]=nil;return end
  local sec=tonumber(wake) or .01
  __host.schedule(function() clock_resume(id) end,math.max(1,math.floor(sec*1000)))
end
function clock.run(fn,...)
  clockId=clockId+1;local id=clockId
  clocks[id]={co=coroutine.create(fn),cancelled=false}
  local args={...};local unpack_args=table.unpack or unpack
  __host.schedule(function() clock_resume(id,unpack_args(args)) end,1)
  return id
end
function clock.sleep(seconds) return coroutine.yield(math.max(.001,seconds or 0)) end
function clock.sync(beats,offset)
  local b=math.max(.001,beats or 1);local now=clock.get_beats()
  local target=(math.floor((now-(offset or 0))/b)+1)*b+(offset or 0)
  return coroutine.yield(math.max(.001,(target-now)*clock.get_beat_sec()))
end
function clock.cancel(id) if clocks[id] then clocks[id].cancelled=true;clocks[id]=nil end end
function clock.cleanup() clocks={} end

metro = {meters={}}
function metro.init(fn,seconds,count)
  local m={time=seconds or 1,count=count or -1,event=fn,stage=1,running=false,id=#metro.meters+1}
  function m:start(time,count,stage)
    if time then self.time=time end
    if count then self.count=count end
    if stage then self.stage=stage end
    self.running=true;local step=0
    local function tick()
      if not self.running then return end
      step=step+1
      if self.event then self.event(step) end
      if self.count>0 and step>=self.count then self.running=false;return end
      __host.schedule(tick,math.max(1,math.floor(self.time*1000)))
    end
    __host.schedule(tick,math.max(1,math.floor(self.time*1000)))
  end
  function m:stop() self.running=false end
  metro.meters[#metro.meters+1]=m;return m
end
function metro.new(id) return metro.init(nil,1,-1) end
function metro.free_all() for _,m in ipairs(metro.meters) do m:stop() end;metro.meters={} end

osc.event = function(path,args,from) end
function __osc_event(path,args) osc.event(path,args,{"android",10111}) end

norns={state={name="norns-pocket"},version={required=nil},none=function()end}
function norns.blank() screen.clear();screen.update() end
