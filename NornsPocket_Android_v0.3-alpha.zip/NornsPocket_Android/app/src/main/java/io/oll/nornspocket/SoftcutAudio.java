package io.oll.nornspocket;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Process;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;

/** Six-voice, two-buffer sampler. No SuperCollider dependency. */
public final class SoftcutAudio {
    public static final int SR=48000, SECONDS=60, VOICES=6, BUFFER_SIZE=SR*SECONDS;
    private final float[][] buffers=new float[2][BUFFER_SIZE];
    public final Voice[] voices=new Voice[VOICES];
    private volatile boolean running=false, recording=false;
    private volatile float inputL=0, inputR=0, outputGain=.75f;
    private static final int MIC_RING_SIZE=32768;
    private final float[] micRing=new float[MIC_RING_SIZE];
    private volatile long micWrite=0, micRead=0;
    private Thread outputThread,inputThread;
    private AudioTrack track;
    private AudioRecord mic;
    private final Context context;
    private final Oscillator[] oscillators=new Oscillator[12];
    public static final class Voice {
        public volatile boolean enabled=false, playing=false, looping=true, recording=false;
        public volatile int buffer=1;
        public volatile double position=0, rate=1, loopStart=0, loopEnd=4;
        public volatile double level=1, pan=0, recLevel=1, preLevel=0, recOffset=0, fadeTime=.01;
        public volatile double input1=0, input2=0;
        public volatile double phaseQuant=0;
    }
    private static final class Oscillator {
        volatile boolean active=false; double phase=0; volatile double frequency=440,amp=.2, decay=.9999;
    }
    public SoftcutAudio(Context c) {
        context=c;
        for(int i=0;i<VOICES;i++) voices[i]=new Voice();
        for(int i=0;i<oscillators.length;i++) oscillators[i]=new Oscillator();
    }
    public void reset() {
        for(Voice v:voices) {
            v.enabled=false;v.playing=false;v.looping=true;v.recording=false;v.buffer=1;
            v.position=0;v.rate=1;v.loopStart=0;v.loopEnd=4;v.level=1;v.pan=0;
            v.recLevel=1;v.preLevel=0;v.recOffset=0;v.fadeTime=.01;v.input1=0;v.input2=0;
        }
    }
    public synchronized void start() {
        if(running)return;
        int min=AudioTrack.getMinBufferSize(SR,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT);
        int bufferBytes=Math.max(8192,min);
        track=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
          .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(SR).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
          .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(bufferBytes).build();
        track.play();running=true;
        outputThread=new Thread(this::outputLoop,"softcut-output");outputThread.start();
    }
    private void outputLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
        final int frames=256;
        short[] samples=new short[frames*2];
        while(running) {
            for(int i=0;i<frames;i++) {
                // Consume one mic sample per output frame instead of holding the last sample of a block.
                long available=micWrite-micRead;
                if(available>MIC_RING_SIZE-1024)micRead=micWrite-1024;
                if(micRead<micWrite){float sample=micRing[(int)(micRead++%MIC_RING_SIZE)];inputL=sample;inputR=sample;}
                else inputL=inputR=0;
                double l=0,r=0;
                for(Voice v:voices) {
                    if(!v.enabled) continue;
                    double len=Math.max(.01,v.loopEnd-v.loopStart);
                    double pos=v.position;
                    if(pos>=v.loopEnd || pos<v.loopStart) {
                        if(v.looping) pos=v.loopStart+(((pos-v.loopStart)%len)+len)%len;
                        else {v.playing=false;v.recording=false;pos=v.loopStart;}
                    }
                    if(v.playing) {
                        float[] b=buffers[v.buffer-1];
                        double sample=interpolated(b,pos*SR);
                        // Simple end-to-start equal-power crossfade for forward playback.
                        if(v.looping && v.rate>0 && v.fadeTime>.001 && pos>v.loopEnd-v.fadeTime) {
                            double a=(v.loopEnd-pos)/v.fadeTime;
                            a=Math.max(0,Math.min(1,a));
                            double p2=v.loopStart+(v.fadeTime-(v.loopEnd-pos));
                            sample=sample*a+interpolated(b,p2*SR)*(1-a);
                        }
                        double leftPan=Math.sqrt((1-Math.max(-1,Math.min(1,v.pan)))*.5);
                        double rightPan=Math.sqrt((1+Math.max(-1,Math.min(1,v.pan)))*.5);
                        l+=sample*v.level*leftPan;r+=sample*v.level*rightPan;
                    }
                    if(v.recording) {
                        int at=(int)((pos+v.recOffset)*SR);
                        if(at>=0 && at<BUFFER_SIZE) {
                            float[] b=buffers[v.buffer-1];
                            double incoming=inputL*v.input1+inputR*v.input2;
                            b[at]=(float)Math.max(-1,Math.min(1,b[at]*v.preLevel+incoming*v.recLevel));
                        }
                    }
                    if(v.playing || v.recording) v.position=pos+v.rate/(double)SR;
                }
                // Minimal internal 'engine.hz' percussion oscillator; not SC PolyPerc synthesis.
                for(Oscillator o:oscillators) {
                    if(!o.active)continue;
                    double s=Math.sin(o.phase)*o.amp;
                    l+=s*.6;r+=s*.6;
                    o.phase+=2*Math.PI*o.frequency/SR;
                    if(o.phase>Math.PI*2)o.phase-=Math.PI*2;
                    o.amp*=o.decay;
                    if(o.amp<.0001)o.active=false;
                }
                samples[2*i]=toPcm(l*outputGain);
                samples[2*i+1]=toPcm(r*outputGain);
            }
            if(track!=null) {
                int result=track.write(samples,0,samples.length,AudioTrack.WRITE_BLOCKING);
                if(result<0) break;
            }
        }
    }
    private static short toPcm(double v){return (short)(Math.max(-1,Math.min(1,v))*32767);}
    private static double interpolated(float[] b,double p) {
        int i=(int)p;
        if(i<0 || i>=b.length)return 0;
        return b[i]+((i+1<b.length?b[i+1]:0)-b[i])*(p-i);
    }
    public void note(double hz,double amp) {
        if(hz<10 || hz>20000)return;
        for(Oscillator o:oscillators) if(!o.active) {
            o.phase=0;o.frequency=hz;o.amp=Math.max(0,Math.min(1,amp));o.decay=Math.pow(.001,1.0/(SR*.65));o.active=true;return;
        }
        Oscillator o=oscillators[0];o.phase=0;o.frequency=hz;o.amp=Math.max(0,Math.min(1,amp));o.active=true;
    }
    public void gain(double v) {outputGain=(float)Math.max(0,Math.min(2,v));}
    public synchronized void stop() {
        running=false;stopInput();
        if(outputThread!=null)try{outputThread.join(600);}catch(InterruptedException e){Thread.currentThread().interrupt();}
        if(track!=null){try{track.pause();track.flush();track.release();}catch(Exception ignored){}track=null;}
    }
    @SuppressLint("MissingPermission")
    public synchronized boolean startInput() {
        if(recording)return true;
        if(context.checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)return false;
        int buffer=Math.max(8192,AudioRecord.getMinBufferSize(SR,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT));
        try {
            mic=new AudioRecord(MediaRecorder.AudioSource.DEFAULT,SR,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,buffer);
            if(mic.getState()!=AudioRecord.STATE_INITIALIZED){mic.release();mic=null;return false;}
            micRead=micWrite=0;
            mic.startRecording();recording=true;
            inputThread=new Thread(() -> {
                Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
                short[] s=new short[256];
                while(recording){
                    AudioRecord current=mic;
                    if(current==null)break;
                    int n=current.read(s,0,s.length);
                    if(n>0){for(int i=0;i<n;i++){micRing[(int)(micWrite%MIC_RING_SIZE)]=s[i]/32768f;micWrite++;}}
                }
            },"softcut-input");inputThread.start();return true;
        }catch(Exception e){if(mic!=null)mic.release();mic=null;return false;}
    }
    public synchronized void stopInput(){
        recording=false;
        if(mic!=null){try{mic.stop();mic.release();}catch(Exception ignored){}mic=null;}
        if(inputThread!=null){try{inputThread.join(300);}catch(InterruptedException e){Thread.currentThread().interrupt();} inputThread=null;}
        inputL=inputR=0;
    }
    public void clear(){for(float[] b:buffers)Arrays.fill(b,0);}
    public void clearChannel(int ch){if(ch>=1 && ch<=2)Arrays.fill(buffers[ch-1],0);}
    public void clearRegion(int ch,double start,double duration) {
        int a=clipFrame(start), b=clipFrame(start+duration);
        if(ch==0){for(float[] data:buffers)Arrays.fill(data,Math.min(a,b),Math.max(a,b),0);}
        else if(ch>=1&&ch<=2)Arrays.fill(buffers[ch-1],Math.min(a,b),Math.max(a,b),0);
    }
    private int clipFrame(double seconds) {return Math.max(0,Math.min(BUFFER_SIZE,(int)Math.round(seconds*SR)));}
    public void copy(int srcCh,int dstCh,double src,double dst,double duration) {
        if(srcCh<1||srcCh>2||dstCh<1||dstCh>2)return;
        int a=clipFrame(src), b=clipFrame(dst), n=Math.min(duration<0?BUFFER_SIZE:clipFrame(duration),Math.min(BUFFER_SIZE-a,BUFFER_SIZE-b));
        if(n>0)System.arraycopy(buffers[srcCh-1],a,buffers[dstCh-1],b,n);
    }
    public void readWav(String path,int sourceChannel,int destinationChannel,double srcStart,double dstStart,double dur,boolean stereo) throws IOException {
        WavIO.Data wav=WavIO.read(new File(path));
        int at=clipFrame(dstStart);
        int n=Math.min(BUFFER_SIZE-at,(int)((dur<=0?wav.frames()/(double)wav.rate:dur)*SR));
        int srcBase=(int)(srcStart*wav.rate);
        for(int i=0;i<n;i++) {
            double samplePos=srcBase+(double)i*wav.rate/SR;
            int j=(int)samplePos;
            if(j>=wav.frames())break;
            float frac=(float)(samplePos-j);
            if(stereo) {
                for(int ch=0;ch<2;ch++) {
                    float[] data=wav.channels[Math.min(ch,wav.channels.length-1)];
                    buffers[ch][at+i]=data[j]+(data[Math.min(j+1,data.length-1)]-data[j])*frac;
                }
            } else {
                float[] data=wav.channels[Math.max(0,Math.min(sourceChannel-1,wav.channels.length-1))];
                buffers[Math.max(0,Math.min(destinationChannel-1,1))][at+i]=data[j]+(data[Math.min(j+1,data.length-1)]-data[j])*frac;
            }
        }
    }
    public void writeWav(String path,int ch,double from,double duration,boolean stereo)throws IOException {
        int at=clipFrame(from),frames=Math.min(BUFFER_SIZE-at,clipFrame(duration<0?SECONDS-from:duration));
        WavIO.write(new File(path),buffers[Math.max(0,Math.min(1,ch-1))],stereo?buffers[1]:null,at,frames,SR);
    }
    public double position(int voice){return voices[Math.max(0,Math.min(5,voice-1))].position;}
    public float[] snapshot(int ch,double from,double duration,int samples) {
        int a=clipFrame(from), n=Math.max(1,Math.min(1024,samples));
        float[] data=new float[n];
        for(int i=0;i<n;i++){
            int p=Math.min(BUFFER_SIZE-1,a+(int)(duration*SR*i/n));
            data[i]=buffers[Math.max(0,Math.min(1,ch-1))][p];
        }
        return data;
    }
}
