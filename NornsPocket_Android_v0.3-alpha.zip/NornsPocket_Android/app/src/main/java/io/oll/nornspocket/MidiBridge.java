package io.oll.nornspocket;

import android.content.Context;
import android.media.midi.MidiDevice;
import android.media.midi.MidiDeviceInfo;
import android.media.midi.MidiInputPort;
import android.media.midi.MidiManager;
import android.media.midi.MidiOutputPort;
import android.media.midi.MidiReceiver;
import android.os.Handler;
import android.os.Looper;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Android MIDI devices: bidirectional physical/virtual MIDI ports. */
public final class MidiBridge {
    public interface Listener { void receive(int port,byte[] bytes); void status(String s); }
    private final MidiManager manager;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final Listener listener;
    private final List<Connection> connections=new ArrayList<>();
    private static final class Connection {
        MidiDevice dev;MidiInputPort out;MidiOutputPort in;String name;
        final MidiStreamParser parser=new MidiStreamParser();
    }
    public MidiBridge(Context context,Listener l){manager=(MidiManager)context.getSystemService(Context.MIDI_SERVICE);listener=l;}
    public synchronized void close(){
        for(Connection c:connections)try{if(c.in!=null)c.in.close();if(c.out!=null)c.out.close();if(c.dev!=null)c.dev.close();}catch(IOException ignored){}
        connections.clear();
    }
    public void scan(){
        close();
        if(manager==null){listener.status("MIDI unavailable on this device");return;}
        MidiDeviceInfo[] devices=manager.getDevices();
        if(devices.length==0){listener.status("No MIDI devices found");return;}
        for(MidiDeviceInfo d:devices)manager.openDevice(d,dev->{
            if(dev==null){listener.status("MIDI open failed");return;}
            Connection c=new Connection();c.dev=dev;
            c.name=d.getProperties().getString(MidiDeviceInfo.PROPERTY_NAME,"MIDI device");
            if(d.getInputPortCount()>0)c.out=dev.openInputPort(0);
            if(d.getOutputPortCount()>0){
                c.in=dev.openOutputPort(0);
                if(c.in!=null){
                    final Connection conn=c;
                    c.in.connect(new MidiReceiver(){
                        @Override public void onSend(byte[] msg,int offset,int count,long timestamp){
                            byte[] bytes=new byte[count];System.arraycopy(msg,offset,bytes,0,count);
                            synchronized(connections){
                                int idx=connections.indexOf(conn);
                                if(idx>=0)for(byte[] message:conn.parser.feed(bytes))listener.receive(idx+1,message);
                            }
                        }
                    });
                }
            }
            synchronized(connections){connections.add(c);listener.status("MIDI: "+connections.size()+" device(s), last: "+c.name);}
        },main);
    }
    public synchronized String names(){
        if(connections.isEmpty())return "none";
        StringBuilder b=new StringBuilder();for(int i=0;i<connections.size();i++){if(i>0)b.append("; ");b.append(i+1).append(": ").append(connections.get(i).name);}return b.toString();
    }
    public void send(int port,byte[] data){
        MidiInputPort out;
        synchronized(this){if(port<1||port>connections.size())return;out=connections.get(port-1).out;}
        if(out!=null)try{out.send(data,0,data.length);}catch(IOException e){listener.status("MIDI output error: "+e.getMessage());}
    }
}
