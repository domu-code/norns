package io.oll.nornspocket;

import java.util.Arrays;

/** Logical 16x8 monome with an 8x8 hardware window and brightness collapse. */
public final class GridState {
    public final int[][] led = new int[8][16];
    public volatile int page = 0;
    public volatile int threshold = 1;
    public volatile int rotation = 0;
    private Runnable changed = () -> {};
    public void setChanged(Runnable r) { changed = r; }
    public synchronized void set(int x, int y, int l) {
        if (x>=1 && x<=16 && y>=1 && y<=8) led[y-1][x-1] = Math.max(0,Math.min(15,l));
    }
    public synchronized void clear(int l) {
        for (int[] row : led) Arrays.fill(row,Math.max(0,Math.min(15,l)));
    }
    public synchronized int get(int x,int y) { return led[y][x]; }
    public void refresh() { changed.run(); }
    public synchronized byte[] seriesFrame() {
        // 2007-2010 series 64: 0x80 + 8 row bitmasks, bit x is physical column x.
        byte[] frame = new byte[9]; frame[0] = (byte)0x80;
        for (int y=0;y<8;y++) {
            int mask=0;
            for (int x=0;x<8;x++) {
                int lx=x, ly=y;
                if(rotation==90) { lx=y; ly=7-x; }
                else if(rotation==180) { lx=7-x; ly=7-y; }
                else if(rotation==270) { lx=7-y; ly=x; }
                if(led[ly][lx+page*8]>=threshold) mask |= 1<<x;
            }
            frame[y+1] = (byte)mask;
        }
        return frame;
    }
    /** physical x/y -> logical x/y (zero-based) */
    public int[] mapPhysical(int x,int y) {
        int lx=x, ly=y;
        if(rotation==90) { lx=y; ly=7-x; }
        else if(rotation==180) { lx=7-x; ly=7-y; }
        else if(rotation==270) { lx=7-y; ly=x; }
        return new int[] {lx+page*8,ly};
    }
}
