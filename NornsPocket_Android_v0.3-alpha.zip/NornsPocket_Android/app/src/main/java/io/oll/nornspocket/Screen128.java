package io.oll.nornspocket;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;

/** Stateful 128x64 monochrome graphics surface, backed by an ARGB bitmap. */
public final class Screen128 {
    public static final int W = 128, H = 64;
    private final Bitmap bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
    private final Canvas canvas = new Canvas(bitmap);
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private Runnable updated = () -> {};
    private float x = 0, y = 0, lineWidth = 1;
    private int level = 15, fontSize = 8;
    private float currentX, currentY;

    public Screen128() { clear(); paint.setTypeface(Typeface.create("monospace", Typeface.NORMAL)); }
    public synchronized void setUpdated(Runnable r) { updated = r; }
    private void color() { int k = (int)(255f * level / 15f); paint.setColor(Color.rgb(k,k,k)); }
    public synchronized void clear() { canvas.drawColor(Color.BLACK); path.reset(); }
    public synchronized void level(int l) { level = Math.min(15, Math.max(0,l)); }
    public synchronized void aa(int on) { paint.setAntiAlias(on != 0); }
    public synchronized void width(float v) { lineWidth = Math.max(0.5f, v); }
    public synchronized void fontSize(int v) { fontSize = Math.max(4, Math.min(28,v)); }
    public synchronized void move(float a, float b) { x=a; y=b; path.moveTo(a,b); currentX=a; currentY=b; }
    public synchronized void moveRel(float a, float b) { move(x+a,y+b); }
    public synchronized void line(float a, float b) { path.lineTo(a,b); currentX=a; currentY=b; x=a; y=b; }
    public synchronized void lineRel(float a, float b) { line(x+a,y+b); }
    public synchronized void rect(float a, float b, float w, float h) { path.addRect(a,b,a+w,b+h,Path.Direction.CW); }
    public synchronized void circle(float a, float b, float r) { path.addCircle(a,b,Math.max(0,r),Path.Direction.CW); }
    public synchronized void arc(float a, float b, float r, float start, float end) {
        path.addArc(a-r,b-r,a+r,b+r,(float)Math.toDegrees(start),(float)Math.toDegrees(end-start));
    }
    public synchronized void pixel(int a, int b) { color(); paint.setStyle(Paint.Style.FILL); canvas.drawPoint(a,b,paint); }
    public synchronized void stroke() { color(); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(lineWidth); canvas.drawPath(path,paint); path.reset(); }
    public synchronized void fill() { color(); paint.setStyle(Paint.Style.FILL); canvas.drawPath(path,paint); path.reset(); }
    public synchronized void text(String s, int align) {
        color(); paint.setStyle(Paint.Style.FILL); paint.setTextSize(fontSize);
        paint.setTypeface(Typeface.create("monospace", Typeface.NORMAL));
        paint.setTextAlign(align < 0 ? Paint.Align.LEFT : align > 0 ? Paint.Align.RIGHT : Paint.Align.CENTER);
        canvas.drawText(s,x,y,paint);
    }
    public synchronized float textWidth(String s) { paint.setTextSize(fontSize); return paint.measureText(s); }
    public synchronized void update() { updated.run(); }
    public synchronized Bitmap image() { return bitmap; }
}
