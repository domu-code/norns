package io.oll.nornspocket;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

/** Split Android MIDI byte streams into individual messages, with running status. */
public final class MidiStreamParser {
    private int runningStatus=0,status=0,wanted=0;
    private final ByteArrayOutputStream pending=new ByteArrayOutputStream();
    public synchronized List<byte[]> feed(byte[] bytes) {
        List<byte[]> out=new ArrayList<>();
        for(byte b:bytes){
            int v=b&255;
            if(v>=0xF8){out.add(new byte[]{b});continue;}
            if(v>=0x80){
                if(v==0xF7){
                    if(status==0xF0){pending.write(v);out.add(pending.toByteArray());}
                    pending.reset();status=0;wanted=0;continue;
                }
                status=v;pending.reset();pending.write(v);
                if(v>=0x80&&v<0xF0){runningStatus=v;wanted=((v&0xF0)==0xC0||(v&0xF0)==0xD0)?2:3;}
                else {runningStatus=0;wanted=(v==0xF1||v==0xF3)?2:v==0xF2?3:v==0xF0?-1:1;}
                if(wanted==1){out.add(pending.toByteArray());pending.reset();status=0;}
            }else{
                if(status==0&&runningStatus!=0){status=runningStatus;wanted=((status&0xF0)==0xC0||(status&0xF0)==0xD0)?2:3;pending.write(status);}
                if(status==0)continue;
                pending.write(v);
                if(wanted>0&&pending.size()==wanted){
                    out.add(pending.toByteArray());pending.reset();status=0;
                }
            }
        }
        return out;
    }
}
