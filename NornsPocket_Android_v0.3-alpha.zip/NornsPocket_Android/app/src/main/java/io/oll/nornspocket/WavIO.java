package io.oll.nornspocket;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;

/** RIFF WAV reader/writer: PCM 8/16/24/32 and IEEE-float 32-bit. */
public final class WavIO {
    public static final class Data {
        public final float[][] channels;
        public final int rate;
        Data(float[][] ch, int r) { channels=ch; rate=r; }
        public int frames() { return channels[0].length; }
    }
    private WavIO() {}
    static int le16(byte[] b,int p) {return (b[p]&255)|((b[p+1]&255)<<8);}
    static int le32(byte[] b,int p) {return (b[p]&255)|((b[p+1]&255)<<8)|((b[p+2]&255)<<16)|((b[p+3]&255)<<24);}
    public static Data read(File file) throws IOException {
        byte[] bytes = Files.readAllBytes(file.toPath());
        if(bytes.length<44 || !new String(bytes,0,4,"US-ASCII").equals("RIFF") || !new String(bytes,8,4,"US-ASCII").equals("WAVE")) throw new IOException("Not a RIFF WAV");
        int fmt=-1, pcm=-1, pcmLen=0;
        for(int p=12;p+8<=bytes.length;) {
            int n=le32(bytes,p+4);
            if(n<0 || (long)p+8+n>bytes.length) throw new IOException("Invalid chunk length");
            String id=new String(bytes,p,4,"US-ASCII");
            if(id.equals("fmt ")) fmt=p+8;
            if(id.equals("data")) { pcm=p+8; pcmLen=n; }
            p+=8+n+(n&1);
        }
        if(fmt<0 || pcm<0 || fmt+16>bytes.length) throw new IOException("Incomplete WAV");
        int type=le16(bytes,fmt), ch=le16(bytes,fmt+2), rate=le32(bytes,fmt+4), bits=le16(bytes,fmt+14);
        if(ch<1 || ch>2 || rate<8000 || rate>192000 || (type!=1 && type!=3) || !(bits==8 || bits==16 || bits==24 || bits==32)) throw new IOException("Unsupported WAV format");
        if(type==3 && bits!=32) throw new IOException("Only 32-bit float WAV supported");
        int frames=pcmLen/(ch*(bits/8));
        float[][] out=new float[ch][frames];
        int p=pcm;
        for(int i=0;i<frames;i++) for(int c=0;c<ch;c++) {
            float value;
            switch(bits) {
                case 8: value=((bytes[p++]&255)-128)/128f; break;
                case 16: value=(short)le16(bytes,p)/32768f; p+=2; break;
                case 24: int v=(bytes[p]&255)|((bytes[p+1]&255)<<8)|((bytes[p+2])<<16); value=v/8388608f; p+=3; break;
                default: int w=le32(bytes,p); value=type==3?Float.intBitsToFloat(w):w/2147483648f; p+=4; break;
            }
            out[c][i] = Float.isFinite(value)?value:0f;
        }
        return new Data(out,rate);
    }
    public static void write(File file, float[] left, float[] right,int start,int frames,int sampleRate) throws IOException {
        File parent=file.getParentFile(); if(parent!=null) parent.mkdirs();
        int channels=right==null?1:2, dataSize=frames*channels*2;
        try(DataOutputStream out=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)))) {
            out.writeBytes("RIFF"); put32(out,36+dataSize); out.writeBytes("WAVEfmt ");
            put32(out,16); put16(out,1); put16(out,channels); put32(out,sampleRate);
            put32(out,sampleRate*channels*2); put16(out,channels*2); put16(out,16);
            out.writeBytes("data"); put32(out,dataSize);
            for(int i=0;i<frames;i++) {
                put16(out,to16(left[start+i]));
                if(right!=null) put16(out,to16(right[start+i]));
            }
        }
    }
    private static int to16(float f) {return (int)(Math.max(-1,Math.min(1,f))*32767f);}
    static void put16(DataOutputStream out,int n)throws IOException {out.writeByte(n);out.writeByte(n>>>8);}
    static void put32(DataOutputStream out,int n)throws IOException {out.writeByte(n);out.writeByte(n>>>8);out.writeByte(n>>>16);out.writeByte(n>>>24);}
}
