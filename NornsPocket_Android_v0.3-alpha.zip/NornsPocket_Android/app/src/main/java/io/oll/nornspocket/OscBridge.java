package io.oll.nornspocket;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Small OSC 1.0 UDP sender/receiver (int, float, string, bool). */
public final class OscBridge {
    public interface Listener {void receive(String path,Object[] args);void status(String status);}
    private final Listener listener;
    private volatile boolean running;
    private DatagramSocket socket;
    private Thread thread;
    public OscBridge(Listener listener){this.listener=listener;}
    public void start(int listenPort){
        stop();
        try {
            socket=new DatagramSocket(listenPort);running=true;
            thread=new Thread(this::listen,"osc-udp");thread.start();
            listener.status("OSC listening on "+listenPort);
        }catch(Exception e){listener.status("OSC unavailable: "+e.getMessage());}
    }
    private void listen(){
        byte[] data=new byte[8192];
        while(running){try{
            DatagramPacket p=new DatagramPacket(data,data.length);socket.receive(p);
            ByteBuffer b=ByteBuffer.wrap(data,0,p.getLength()).order(ByteOrder.BIG_ENDIAN);
            String path=readString(b);String tags=readString(b);
            if(!tags.startsWith(","))continue;
            List<Object> args=new ArrayList<>();
            for(int i=1;i<tags.length();i++)switch(tags.charAt(i)){
                case 'i':args.add(b.getInt());break;
                case 'f':args.add(b.getFloat());break;
                case 's':args.add(readString(b));break;
                case 'T':args.add(true);break;
                case 'F':args.add(false);break;
                default:throw new IOException("Unsupported OSC type");
            }
            listener.receive(path,args.toArray());
        }catch(Exception e){if(running)listener.status("OSC packet ignored: "+e.getMessage());}}
    }
    private static String readString(ByteBuffer b){
        int start=b.position();while(b.remaining()>0 && b.get()!=0){}
        int end=b.position()-1;
        if(end<start)throw new IllegalArgumentException("OSC string missing terminator");
        byte[] str=new byte[end-start];int after=b.position();b.position(start);b.get(str);
        b.position(Math.min(b.limit(),(after+3)&~3));return new String(str,StandardCharsets.UTF_8);
    }
    private static void putString(DataOutputStream out,String s)throws IOException {
        byte[] data=s.getBytes(StandardCharsets.UTF_8);out.write(data);out.writeByte(0);
        int size=data.length+1;while(size++%4!=0)out.writeByte(0);
    }
    public void send(String host,int port,String path,Object[] args)throws IOException {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();DataOutputStream out=new DataOutputStream(bytes);
        putString(out,path);StringBuilder tags=new StringBuilder(",");
        for(Object arg:args){if(arg instanceof String)tags.append('s');else if(arg instanceof Integer)tags.append('i');else if(arg instanceof Boolean)tags.append((Boolean)arg?'T':'F');else tags.append('f');}
        putString(out,tags.toString());
        for(Object a:args){if(a instanceof String)putString(out,(String)a);else if(a instanceof Integer)out.writeInt((Integer)a);else if(a instanceof Boolean){}else out.writeFloat(((Number)a).floatValue());}
        byte[] packet=bytes.toByteArray();DatagramPacket p=new DatagramPacket(packet,packet.length,InetAddress.getByName(host),port);
        try(DatagramSocket sending=new DatagramSocket()){sending.send(p);}
    }
    public void stop(){running=false;if(socket!=null){socket.close();socket=null;}}
}
