package io.oll.nornspocket;

import android.os.Handler;
import android.os.HandlerThread;
import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.VarArgFunction;
import org.luaj.vm2.lib.jse.JsePlatform;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/** Single-threaded Lua script host with norns-style modules and Android backends. */
public final class LuaRuntime {
    public interface Listener { void status(String s); void redraw(); }
    @FunctionalInterface interface Invoke {Varargs call(Varargs a) throws Exception;}
    private final HandlerThread thread=new HandlerThread("norns-lua");
    private Handler handler;
    private final Screen128 screen;
    private final GridState grid;
    private final SoftcutAudio audio;
    private final MidiBridge midi;
    private final OscBridge osc;
    private final Listener listener;
    private final File audioDir;
    private Globals globals;
    private int generation=0;
    private File currentScript;
    private boolean loaded=false;
    private boolean phasePolling=false;
    public LuaRuntime(Screen128 screen,GridState grid,SoftcutAudio audio,MidiBridge midi,OscBridge osc,File audioDir,Listener listener){
        this.screen=screen;this.grid=grid;this.audio=audio;this.midi=midi;this.osc=osc;this.audioDir=audioDir;this.listener=listener;
        thread.start();handler=new Handler(thread.getLooper());
    }
    public void runOnLua(Runnable r){handler.post(r);}
    private void status(String s){listener.status(s);}
    private static LuaValue nil(){return LuaValue.NIL;}
    private static double number(Varargs a,int n,double fallback){return a.narg()>=n&&!a.arg(n).isnil()?a.arg(n).todouble():fallback;}
    private static int integer(Varargs a,int n,int fallback){return (int)number(a,n,fallback);}
    private static String string(Varargs a,int n,String fallback){return a.narg()>=n&&!a.arg(n).isnil()?a.arg(n).tojstring():fallback;}
    private static LuaValue lv(double v){return LuaValue.valueOf(v);}
    private static LuaValue lv(int v){return LuaValue.valueOf(v);}
    private static LuaValue lv(String v){return LuaValue.valueOf(v);}
    private static void fn(LuaTable table,String name,Invoke action){
        table.set(name,new VarArgFunction(){@Override public Varargs invoke(Varargs a){
            try {return action.call(a);}catch(Exception e){throw new RuntimeException(name+": "+e.getMessage(),e);}
        }});
    }
    private static LuaTable table(){return new LuaTable();}
    private static LuaTable values(double... numbers){LuaTable t=table();for(int i=0;i<numbers.length;i++)t.set(i+1,lv(numbers[i]));return t;}
    private void call(String name,LuaValue...args){
        if(!loaded||globals==null)return;
        LuaValue f=globals.get(name);if(f.isfunction())try{f.invoke(LuaValue.varargsOf(args));}catch(Exception e){status("Lua "+name+": "+e.getMessage());}
    }
    public void load(File script){runOnLua(()->loadNow(script));}
    private void loadNow(File script){
        generation++;loaded=false;phasePolling=false;currentScript=script;audio.reset();grid.clear(0);grid.refresh();screen.clear();screen.update();
        try {
            globals=JsePlatform.standardGlobals();
            // Prevent untrusted downloaded scripts from using LuaJ's Java reflection bridge.
            globals.set("luajava",LuaValue.NIL);
            LuaValue os=globals.get("os");
            if(os.istable()){os.set("execute",LuaValue.NIL);os.set("remove",LuaValue.NIL);os.set("rename",LuaValue.NIL);}
            installModules();
            String bootstrap=readAssetBootstrap();
            globals.load(bootstrap,"norns_bootstrap").call();
            String source=new String(Files.readAllBytes(script.toPath()),StandardCharsets.UTF_8);
            globals.load(source,"@"+script.getName()).call();
            loaded=true;
            call("init");call("redraw");
            status("Loaded "+script.getName());
        }catch(Exception e){loaded=false;status("Script error: "+e.getMessage());}
    }
    private String readAssetBootstrap() throws IOException {
        try(java.io.InputStream in=screenContext.open("bootstrap.lua")){
            java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] b=new byte[4096];int n;
            while((n=in.read(b))>=0)out.write(b,0,n);
            return out.toString("UTF-8");
        }
    }
    private AssetOpener screenContext;
    public interface AssetOpener { java.io.InputStream open(String path) throws IOException; }
    public void setAssetOpener(AssetOpener a){screenContext=a;}
    private void installModules(){
        LuaTable sc=table();
        fn(sc,"clear",a->{screen.clear();return nil();});
        fn(sc,"update",a->{screen.update();return nil();});
        fn(sc,"level",a->{screen.level(integer(a,1,15));return nil();});
        fn(sc,"aa",a->{screen.aa(integer(a,1,1));return nil();});
        fn(sc,"line_width",a->{screen.width((float)number(a,1,1));return nil();});
        fn(sc,"font_face",a->nil());
        fn(sc,"font_size",a->{screen.fontSize(integer(a,1,8));return nil();});
        fn(sc,"move",a->{screen.move((float)number(a,1,0),(float)number(a,2,0));return nil();});
        fn(sc,"move_rel",a->{screen.moveRel((float)number(a,1,0),(float)number(a,2,0));return nil();});
        fn(sc,"line",a->{screen.line((float)number(a,1,0),(float)number(a,2,0));return nil();});
        fn(sc,"line_rel",a->{screen.lineRel((float)number(a,1,0),(float)number(a,2,0));return nil();});
        fn(sc,"rect",a->{screen.rect((float)number(a,1,0),(float)number(a,2,0),(float)number(a,3,0),(float)number(a,4,0));return nil();});
        fn(sc,"circle",a->{screen.circle((float)number(a,1,0),(float)number(a,2,0),(float)number(a,3,0));return nil();});
        fn(sc,"arc",a->{screen.arc((float)number(a,1,0),(float)number(a,2,0),(float)number(a,3,0),(float)number(a,4,0),(float)number(a,5,0));return nil();});
        fn(sc,"pixel",a->{screen.pixel(integer(a,1,0),integer(a,2,0));return nil();});
        fn(sc,"stroke",a->{screen.stroke();return nil();});
        fn(sc,"fill",a->{screen.fill();return nil();});
        fn(sc,"text",a->{screen.text(string(a,1,""),-1);return nil();});
        fn(sc,"text_right",a->{screen.text(string(a,1,""),1);return nil();});
        fn(sc,"text_center",a->{screen.text(string(a,1,""),0);return nil();});
        fn(sc,"text_extents",a->{float w=screen.textWidth(string(a,1,""));return LuaValue.varargsOf(new LuaValue[]{lv(w),lv(8)});});
        globals.set("screen",sc);

        LuaTable hooks=table();
        fn(hooks,"grid_set",a->{grid.set(integer(a,1,1),integer(a,2,1),integer(a,3,0));return nil();});
        fn(hooks,"grid_all",a->{grid.clear(integer(a,1,0));return nil();});
        fn(hooks,"grid_refresh",a->{grid.refresh();return nil();});
        fn(hooks,"midi_send",a->{int port=integer(a,1,1);LuaValue t=a.arg(2);int n=t.length();byte[] message=new byte[n];for(int i=0;i<n;i++)message[i]=(byte)t.get(i+1).toint();midi.send(port,message);return nil();});
        fn(hooks,"schedule",a->{LuaValue callback=a.arg(1);int ms=Math.max(1,Math.min(86400000,integer(a,2,10)));int epoch=generation;
            handler.postDelayed(()->{if(epoch==generation)try{callback.call();}catch(Exception e){status("timer: "+e.getMessage());}},ms);
            return nil();});
        fn(hooks,"include",a->{
            String path=string(a,1,"");if(path.isEmpty())return nil();
            if(!path.endsWith(".lua"))path+=".lua";
            File file=new File(currentScript.getParentFile(),path).getCanonicalFile();
            if(!file.toPath().startsWith(currentScript.getParentFile().getCanonicalFile().toPath()))throw new IOException("include outside script folder");
            return globals.load(new String(Files.readAllBytes(file.toPath()),StandardCharsets.UTF_8),"@"+file.getName()).call();
        });
        fn(hooks,"status",a->{status(string(a,1,""));return nil();});
        fn(hooks,"seconds",a->lv(System.nanoTime()/1.0e9));
        globals.set("__host",hooks);

        LuaTable path=table();path.set("audio",lv(audioDir.getAbsolutePath()+"/"));
        path.set("dust",lv(currentScript.getParentFile().getAbsolutePath()+"/"));
        path.set("data",lv(currentScript.getParentFile().getAbsolutePath()+"/"));
        path.set("code",lv(currentScript.getParentFile().getAbsolutePath()+"/"));
        globals.set("_path",path);

        LuaTable softcut=table();
        fn(softcut,"reset",a->{audio.reset();return nil();});
        fn(softcut,"enable",a->{voice(a).enabled=integer(a,2,0)!=0;return nil();});
        fn(softcut,"play",a->{voice(a).playing=integer(a,2,0)!=0;return nil();});
        fn(softcut,"rec",a->{voice(a).recording=integer(a,2,0)!=0;return nil();});
        fn(softcut,"loop",a->{voice(a).looping=integer(a,2,1)!=0;return nil();});
        fn(softcut,"rate",a->{voice(a).rate=number(a,2,1);return nil();});
        fn(softcut,"position",a->{voice(a).position=number(a,2,0);return nil();});
        fn(softcut,"loop_start",a->{voice(a).loopStart=Math.max(0,number(a,2,0));return nil();});
        fn(softcut,"loop_end",a->{voice(a).loopEnd=Math.min(SoftcutAudio.SECONDS,number(a,2,4));return nil();});
        fn(softcut,"level",a->{voice(a).level=number(a,2,1);return nil();});
        fn(softcut,"pan",a->{voice(a).pan=number(a,2,0);return nil();});
        fn(softcut,"buffer",a->{voice(a).buffer=Math.max(1,Math.min(2,integer(a,2,1)));return nil();});
        fn(softcut,"rec_level",a->{voice(a).recLevel=number(a,2,1);return nil();});
        fn(softcut,"pre_level",a->{voice(a).preLevel=number(a,2,0);return nil();});
        fn(softcut,"rec_offset",a->{voice(a).recOffset=number(a,2,0);return nil();});
        fn(softcut,"fade_time",a->{voice(a).fadeTime=Math.max(0,number(a,2,.01));return nil();});
        fn(softcut,"level_input_cut",a->{SoftcutAudio.Voice v=audio.voices[Math.max(0,Math.min(5,integer(a,2,1)-1))];if(integer(a,1,1)==1)v.input1=number(a,3,0);else v.input2=number(a,3,0);return nil();});
        fn(softcut,"voice_sync",a->{audio.voices[Math.max(0,Math.min(5,integer(a,1,1)-1))].position=audio.position(integer(a,2,1))+number(a,3,0);return nil();});
        fn(softcut,"buffer_clear",a->{audio.clear();return nil();});
        fn(softcut,"buffer_clear_channel",a->{audio.clearChannel(integer(a,1,1));return nil();});
        fn(softcut,"buffer_clear_region",a->{audio.clearRegion(0,number(a,1,0),number(a,2,0));return nil();});
        fn(softcut,"buffer_clear_region_channel",a->{audio.clearRegion(integer(a,1,1),number(a,2,0),number(a,3,0));return nil();});
        fn(softcut,"buffer_copy_mono",a->{audio.copy(integer(a,1,1),integer(a,2,1),number(a,3,0),number(a,4,0),number(a,5,0));return nil();});
        fn(softcut,"buffer_copy_stereo",a->{for(int ch=1;ch<=2;ch++)audio.copy(ch,ch,number(a,1,0),number(a,2,0),number(a,3,0));return nil();});
        fn(softcut,"buffer_read_mono",a->{audio.readWav(string(a,1,""),integer(a,5,1),integer(a,6,1),number(a,2,0),number(a,3,0),number(a,4,-1),false);return nil();});
        fn(softcut,"buffer_read_stereo",a->{audio.readWav(string(a,1,""),1,1,number(a,2,0),number(a,3,0),number(a,4,-1),true);return nil();});
        fn(softcut,"buffer_write_mono",a->{audio.writeWav(string(a,1,""),integer(a,4,1),number(a,2,0),number(a,3,-1),false);return nil();});
        fn(softcut,"buffer_write_stereo",a->{audio.writeWav(string(a,1,""),1,number(a,2,0),number(a,3,-1),true);return nil();});
        fn(softcut,"query_position",a->{LuaValue cb=globals.get("__softcut_position_callback");if(cb.isfunction())cb.call(lv(integer(a,1,1)),lv(audio.position(integer(a,1,1))));return nil();});
        fn(softcut,"event_position",a->{globals.set("__softcut_position_callback",a.arg(1));return nil();});
        fn(softcut,"phase_quant",a->{voice(a).phaseQuant=number(a,2,.1);return nil();});
        fn(softcut,"event_phase",a->{globals.set("__softcut_phase_callback",a.arg(1));return nil();});
        fn(softcut,"poll_start_phase",a->{
            if(!phasePolling){phasePolling=true;schedulePhasePoll(generation);}return nil();
        });
        fn(softcut,"poll_stop_phase",a->{phasePolling=false;return nil();});
        fn(softcut,"render_buffer",a->{
            LuaValue cb=globals.get("__softcut_render_callback");if(!cb.isfunction())return nil();
            int channel=integer(a,1,1);double from=number(a,2,0),dur=number(a,3,1);
            float[] samples=audio.snapshot(channel,from,dur,integer(a,4,128));LuaTable t=table();
            for(int i=0;i<samples.length;i++)t.set(i+1,lv(samples[i]));
            cb.invoke(LuaValue.varargsOf(new LuaValue[]{lv(channel),lv(from),lv(dur/samples.length),t}));return nil();
        });
        fn(softcut,"event_render",a->{globals.set("__softcut_render_callback",a.arg(1));return nil();});
        globals.set("softcut",softcut);

        LuaTable synth=table();synth.set("name",lv("AndroidSine"));
        fn(synth,"hz",a->{audio.note(number(a,1,440),.25);return nil();});
        fn(synth,"note_on",a->{audio.note(440*Math.pow(2,(number(a,1,69)-69)/12),number(a,2,100)/127);return nil();});
        globals.set("engine",synth);

        LuaTable audioModule=table();
        fn(audioModule,"level_dac",a->{audio.gain(number(a,1,1));return nil();});
        fn(audioModule,"level_cut",a->nil());
        fn(audioModule,"level_adc",a->nil());
        fn(audioModule,"level_eng",a->nil());
        globals.set("audio",audioModule);

        LuaTable oscTable=table();
        fn(oscTable,"send",a->{LuaValue address=a.arg(1);String host=address.get(1).tojstring();int port=address.get(2).toint();String path=a.arg(2).tojstring();LuaValue values=a.arg(3);List<Object> args=new ArrayList<>();
            for(int i=1;i<=values.length();i++){LuaValue v=values.get(i);if(v.isstring() && !v.isnumber())args.add(v.tojstring());else if(v.isint())args.add(v.toint());else if(v.isnumber())args.add(v.tofloat());else if(v.isboolean())args.add(v.toboolean());}
            osc.send(host,port,path,args.toArray());return nil();});
        globals.set("osc",oscTable);
    }
    private void schedulePhasePoll(int epoch){
        handler.postDelayed(()->{
            if(!phasePolling||epoch!=generation||globals==null)return;
            LuaValue callback=globals.get("__softcut_phase_callback");
            if(callback.isfunction())for(int i=1;i<=SoftcutAudio.VOICES;i++)try{
                SoftcutAudio.Voice v=audio.voices[i-1];
                if(v.enabled)callback.call(lv(i),lv(v.position));
            }catch(Exception e){status("phase callback: "+e.getMessage());}
            schedulePhasePoll(epoch);
        },50);
    }
    private SoftcutAudio.Voice voice(Varargs a) {return audio.voices[Math.max(0,Math.min(5,integer(a,1,1)-1))];}
    public void key(int n,int z){runOnLua(()->call("key",lv(n),lv(z)));}
    public void enc(int n,int d){runOnLua(()->call("enc",lv(n),lv(d)));}
    public void gridKey(int x,int y,int z){runOnLua(()->call("__grid_key",lv(x),lv(y),lv(z)));}
    public void midiEvent(int port,byte[] bytes){runOnLua(()->{
        LuaTable t=table();for(int i=0;i<bytes.length;i++)t.set(i+1,lv(bytes[i]&255));call("__midi_event",lv(port),t);
    });}
    public void oscEvent(String path,Object[] args){runOnLua(()->{
        LuaTable t=table();for(int i=0;i<args.length;i++){Object a=args[i];t.set(i+1,a instanceof Number?lv(((Number)a).doubleValue()):a instanceof Boolean?LuaValue.valueOf((Boolean)a):lv(a.toString()));}
        call("__osc_event",lv(path),t);
    });}
    public void redraw(){runOnLua(()->call("redraw"));}
    public void close(){generation++;thread.quitSafely();}
}
