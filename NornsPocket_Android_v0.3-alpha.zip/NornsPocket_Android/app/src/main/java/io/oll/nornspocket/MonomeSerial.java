package io.oll.nornspocket;

import android.app.PendingIntent;
import android.os.Build;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;

/** 2007-2010 'series' monome 64 FTDI USB serial driver. */
public final class MonomeSerial {
    public interface Listener { void key(int x,int y,int z);void status(String s); }
    private static final String PERMISSION="io.oll.nornspocket.USB_MONOME";
    private final Context context;
    private final UsbManager manager;
    private final Listener listener;
    private UsbDeviceConnection connection;
    private UsbInterface iface;
    private UsbEndpoint bulkIn,bulkOut;
    private Thread readThread;
    private volatile boolean listening=false;
    private int pending=-1;
    private final BroadcastReceiver receiver=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent i){
            if(PERMISSION.equals(i.getAction())) {
                UsbDevice dev=i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if(i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED,false)&&dev!=null)open(dev);
                else listener.status("USB permission denied");
            }
        }
    };
    public MonomeSerial(Context c,Listener l){
        context=c;manager=(UsbManager)c.getSystemService(Context.USB_SERVICE);listener=l;
        if(Build.VERSION.SDK_INT>=33)c.registerReceiver(receiver,new IntentFilter(PERMISSION),Context.RECEIVER_NOT_EXPORTED);
        else c.registerReceiver(receiver,new IntentFilter(PERMISSION));
    }
    public void connect(){
        if(manager==null)return;
        for(UsbDevice d:manager.getDeviceList().values()) if(d.getVendorId()==0x0403){
            listener.status("FTDI device found: "+d.getDeviceName());
            if(manager.hasPermission(d))open(d);
            else {
                Intent intent=new Intent(PERMISSION).setPackage(context.getPackageName());
                PendingIntent p=PendingIntent.getBroadcast(context,0,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_MUTABLE);
                manager.requestPermission(d,p);
            }
            return;
        }
        listener.status("No FTDI USB device found; connect via OTG/hub");
    }
    private synchronized void open(UsbDevice dev){
        close();
        try {
            for(int i=0;i<dev.getInterfaceCount();i++) {
                UsbInterface test=dev.getInterface(i);
                UsbEndpoint in=null,out=null;
                for(int j=0;j<test.getEndpointCount();j++) {
                    UsbEndpoint e=test.getEndpoint(j);
                    if(e.getType()!=UsbConstants.USB_ENDPOINT_XFER_BULK)continue;
                    if(e.getDirection()==UsbConstants.USB_DIR_IN)in=e;else out=e;
                }
                if(in!=null&&out!=null){iface=test;bulkIn=in;bulkOut=out;break;}
            }
            if(iface==null)throw new IllegalStateException("No FTDI bulk interface");
            connection=manager.openDevice(dev);
            if(connection==null||!connection.claimInterface(iface,true))throw new IllegalStateException("Unable to claim USB interface");
            int index=iface.getId()+1;
            // FT232 USB control messages, 115200 baud / 8N1, RTS/CTS disabled.
            ctrl(0,0,index);ctrl(3,0x001A,index);ctrl(4,8,index);ctrl(2,0,index);
            listening=true;pending=-1;
            readThread=new Thread(this::readLoop,"monome-series-ftdi");readThread.start();
            listener.status("Connected: FTDI monome series (115200 baud)");
        }catch(Exception e){listener.status("Monome USB: "+e.getMessage());close();}
    }
    private void ctrl(int request,int value,int index){
        if(connection.controlTransfer(0x40,request,value,index,null,0,2000)<0) throw new IllegalStateException("FTDI config request "+request+" failed");
    }
    private void readLoop(){
        byte[] bytes=new byte[512];
        while(listening){
            UsbDeviceConnection c=connection;
            if(c==null)break;
            int n=c.bulkTransfer(bulkIn,bytes,bytes.length,150);
            if(n<=2)continue;
            // FTDI inserts two modem-status bytes at the start of each 64-byte USB packet.
            for(int base=0;base<n;base+=64){
                int end=Math.min(n,base+64);
                for(int i=base+2;i<end;i++)parse(bytes[i]&255);
            }
        }
    }
    private void parse(int v){
        if(pending<0){pending=v;return;}
        int command=pending;pending=-1;
        if(command==0x00||command==0x10)listener.key((v>>4)&15,v&15,command==0?1:0);
    }
    public synchronized void sendFrame(byte[] data){
        if(connection==null||bulkOut==null)return;
        int n=connection.bulkTransfer(bulkOut,data,data.length,200);
        if(n!=data.length)listener.status("Monome LED transfer failed");
    }
    public synchronized void close(){
        listening=false;
        if(connection!=null){try{if(iface!=null)connection.releaseInterface(iface);}catch(Exception ignored){}
            connection.close();connection=null;}
        bulkIn=bulkOut=null;iface=null;
    }
    public void destroy(){close();try{context.unregisterReceiver(receiver);}catch(Exception ignored){}}
}
