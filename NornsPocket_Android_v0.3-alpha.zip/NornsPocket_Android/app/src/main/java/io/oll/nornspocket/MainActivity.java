package io.oll.nornspocket;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;

/** Norns Pocket: on-device Lua scripts, 128x64 UI, monome, MIDI, microphone, Softcut. */
public final class MainActivity extends Activity {
    private static final int BG=0xFF0C1214, PANEL=0xFF192225, ACCENT=0xFFD9B86E, MUTED=0xFF819394;
    private static final int IMPORT_LUA=101,IMPORT_WAV=102,MIC_PERMISSION=103;
    private File scripts,audioFolder;
    private Screen128 screen;
    private GridState grid;
    private SoftcutAudio audio;
    private MidiBridge midi;
    private MonomeSerial monome;
    private OscBridge osc;
    private LuaRuntime lua;
    private TextView status;
    private Spinner picker;
    private Button pageButton,micButton,brightnessButton,rotationButton;
    private DisplayView display;
    private GridView gridView;
    private boolean micEnabled=false;
    private int startupSelected=0;
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        scripts=new File(getFilesDir(),"scripts");audioFolder=new File(getFilesDir(),"audio");
        scripts.mkdirs();audioFolder.mkdirs();installDemos();installFactoryAudio();
        screen=new Screen128();grid=new GridState();audio=new SoftcutAudio(this);
        midi=new MidiBridge(this,new MidiBridge.Listener(){
            @Override public void receive(int port,byte[]bytes){if(lua!=null)lua.midiEvent(port,bytes);}
            @Override public void status(String s){showStatus(s);}
        });
        monome=new MonomeSerial(this,new MonomeSerial.Listener(){
            @Override public void key(int x,int y,int z){int[] pos=grid.mapPhysical(x,y);if(lua!=null)lua.gridKey(pos[0]+1,pos[1]+1,z);}
            @Override public void status(String s){showStatus(s);}
        });
        osc=new OscBridge(new OscBridge.Listener(){
            @Override public void receive(String p,Object[] args){if(lua!=null)lua.oscEvent(p,args);}
            @Override public void status(String s){showStatus(s);}
        });
        lua=new LuaRuntime(screen,grid,audio,midi,osc,audioFolder,new LuaRuntime.Listener(){
            @Override public void status(String s){showStatus(s);}
            @Override public void redraw(){if(display!=null)runOnUiThread(()->display.invalidate());}
        });
        lua.setAssetOpener(path->getAssets().open("lua/"+path));
        createUI();
        screen.setUpdated(()->runOnUiThread(()->display.invalidate()));
        grid.setChanged(()->{runOnUiThread(()->gridView.invalidate());monome.sendFrame(grid.seriesFrame());});
        refreshScripts();
        try{audio.start();}catch(Exception e){showStatus("AudioTrack: "+e.getMessage());}
        midi.scan();osc.start(10111);
        File[] files=scriptFiles();if(files.length>0)lua.load(files[0]);
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int stroke){
        GradientDrawable s=new GradientDrawable();s.setColor(color);s.setCornerRadius(dp(8));
        s.setStroke(dp(1),stroke);return s;
    }
    private TextView label(String str,int size,int color){
        TextView t=new TextView(this);t.setText(str);t.setTextSize(size);t.setTextColor(color);
        t.setTypeface(Typeface.create("monospace",Typeface.NORMAL));return t;
    }
    private Button btn(String text){
        Button b=new Button(this);b.setAllCaps(false);b.setText(text);b.setTextSize(12);
        b.setTextColor(ACCENT);b.setBackground(shape(PANEL,0xFF334348));
        b.setPadding(dp(10),0,dp(10),0);b.setMinHeight(dp(38));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,dp(40));
        p.setMargins(dp(2),dp(2),dp(2),dp(2));b.setLayoutParams(p);return b;
    }
    private LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void createUI(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(12),dp(12),dp(16));scroll.addView(root);setContentView(scroll);
        TextView title=label("NORNS / POCKET",22,ACCENT);title.setTypeface(Typeface.create("monospace",Typeface.BOLD));
        root.addView(title);
        TextView subtitle=label("LUA  •  MONOME  •  MIDI  •  SOFTCUT",10,MUTED);root.addView(subtitle);
        picker=new Spinner(this);picker.setBackground(shape(PANEL,0xFF334348));
        root.addView(picker,new LinearLayout.LayoutParams(-1,dp(44)));
        LinearLayout fileControls=horizontal();root.addView(fileControls);
        Button load=btn("LOAD");load.setOnClickListener(v->{File[] f=scriptFiles();int n=picker.getSelectedItemPosition();if(n>=0&&n<f.length)lua.load(f[n]);});fileControls.addView(load);
        Button importLua=btn("+ LUA");importLua.setOnClickListener(v->openFile(IMPORT_LUA));fileControls.addView(importLua);
        Button importAudio=btn("+ WAV");importAudio.setOnClickListener(v->openFile(IMPORT_WAV));fileControls.addView(importAudio);
        Button help=btn("?");help.setOnClickListener(v->showHelp());fileControls.addView(help);
        display=new DisplayView();LinearLayout.LayoutParams oledParams=new LinearLayout.LayoutParams(-1,dp(204));
        oledParams.setMargins(0,dp(12),0,dp(9));root.addView(display,oledParams);
        TextView caption=label("K1–K3 / E1–E3",11,MUTED);caption.setGravity(Gravity.CENTER);root.addView(caption);
        LinearLayout knobs=horizontal();knobs.setWeightSum(3);root.addView(knobs);
        for(int n=1;n<=3;n++){
            EncoderView encoder=new EncoderView(n);
            knobs.addView(encoder,new LinearLayout.LayoutParams(0,dp(100),1));
        }
        LinearLayout keys=horizontal();keys.setWeightSum(3);root.addView(keys);
        for(int n=1;n<=3;n++){
            final int idx=n;
            Button k=btn("K"+n);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(45),1);p.setMargins(dp(3),dp(2),dp(3),dp(2));keys.addView(k,p);
            k.setOnTouchListener((v,event)->{
                int action=event.getActionMasked();
                if(action==MotionEvent.ACTION_DOWN){lua.key(idx,1);k.setTextColor(Color.WHITE);return true;}
                if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){lua.key(idx,0);k.setTextColor(ACCENT);return true;}
                return true;
            });
        }
        LinearLayout gridHeader=horizontal();LinearLayout.LayoutParams gh=new LinearLayout.LayoutParams(-1,dp(40));gh.topMargin=dp(12);root.addView(gridHeader,gh);
        gridHeader.addView(label("MONOME 16×8",13,ACCENT),new LinearLayout.LayoutParams(0,-2,1));
        pageButton=btn("64 PAGE A");pageButton.setOnClickListener(v->{grid.page=1-grid.page;pageButton.setText(grid.page==0?"64 PAGE A":"64 PAGE B");grid.refresh();});gridHeader.addView(pageButton);
        gridView=new GridView();root.addView(gridView,new LinearLayout.LayoutParams(-1,dp(168)));
        LinearLayout devices1=horizontal();root.addView(devices1);
        Button usb=btn("MONOME USB");usb.setOnClickListener(v->monome.connect());devices1.addView(usb);
        Button rescan=btn("MIDI SCAN");rescan.setOnClickListener(v->midi.scan());devices1.addView(rescan);
        micButton=btn("MIC OFF");micButton.setOnClickListener(v->toggleMic());devices1.addView(micButton);
        LinearLayout devices2=horizontal();root.addView(devices2);
        brightnessButton=btn("LED ≥1");brightnessButton.setOnClickListener(v->{
            int t=grid.threshold;grid.threshold=t==1?4:t==4?8:t==8?12:1;
            brightnessButton.setText("LED ≥"+grid.threshold);grid.refresh();
        });devices2.addView(brightnessButton);
        rotationButton=btn("ROT 0°");rotationButton.setOnClickListener(v->{grid.rotation=(grid.rotation+90)%360;rotationButton.setText("ROT "+grid.rotation+"°");grid.refresh();});devices2.addView(rotationButton);
        status=label("READY",11,MUTED);status.setPadding(dp(2),dp(12),dp(2),dp(12));root.addView(status);
    }
    private void showHelp(){
        new android.app.AlertDialog.Builder(this).setTitle("Norns Pocket controls")
          .setMessage("Load any .lua file from the system document picker. Built-in scripts: Pocket Grid, Tape Garden, MIDI Monitor.\n\n"+
            "USB keyboard:\nF1/F2/F3 = hold norns keys\nQ/W/E = encoder +1\nA/S/D = encoder -1\nG = physical 64 page A/B\n\n"+
            "MIDI: connect a USB MIDI interface, then MIDI SCAN. MIDI port numbering starts at 1.\n\n"+
            "Original monome 64: connect through a powered USB OTG hub, tap MONOME USB and grant permission. LEDs are on/off; use the LED threshold button.\n\n"+
            "Tape Garden: tap MIC OFF to request recording permission. K2 overdubs microphone, K3 toggles playback. E1 loop seconds, E2 rate, E3 feedback.\n\n"+
            "Audio: 60 seconds per buffer, two buffers, six voices. PCM WAV import supported. LuaJ compatibility is partial; SuperCollider engines are not included.")
          .setPositiveButton("OK",null).show();
    }
    private void openFile(int request){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,request);
    }
    @Override protected void onActivityResult(int request,int result,Intent intent){
        super.onActivityResult(request,result,intent);
        if(result!=RESULT_OK||intent==null||intent.getData()==null)return;
        if(request!=IMPORT_LUA&&request!=IMPORT_WAV)return;
        try{
            String name="imported_"+System.currentTimeMillis()+(request==IMPORT_LUA?".lua":".wav");
            try(android.database.Cursor c=getContentResolver().query(intent.getData(),null,null,null,null)){
                if(c!=null&&c.moveToFirst()){
                    int col=c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                    if(col>=0)name=c.getString(col);
                }
            }
            name=name.replaceAll("[^a-zA-Z0-9._-]","_");
            if(name.isEmpty()||!name.toLowerCase().endsWith(request==IMPORT_LUA?".lua":".wav"))throw new IOException("Expected "+(request==IMPORT_LUA?".lua":".wav")+" filename");
            File dir=request==IMPORT_LUA?scripts:audioFolder;
            File destination=new File(dir,name);
            try(InputStream in=getContentResolver().openInputStream(intent.getData());FileOutputStream out=new FileOutputStream(destination)){
                if(in==null)throw new IOException("Cannot open document");
                byte[] buf=new byte[8192];int n;long total=0;
                while((n=in.read(buf))!=-1){total+=n;if(total>32*1024*1024)throw new IOException("File is over the 32 MB import limit");out.write(buf,0,n);}
            }
            showStatus("Imported: "+destination.getName()+" ("+dir.getName()+")");refreshScripts();
        }catch(Exception e){showStatus("Import failed: "+e.getMessage());}
    }
    private void toggleMic(){
        if(micEnabled){audio.stopInput();micEnabled=false;micButton.setText("MIC OFF");return;}
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC_PERMISSION);return;}
        micEnabled=audio.startInput();micButton.setText(micEnabled?"MIC ON":"MIC ERROR");
        showStatus(micEnabled?"Microphone routed to Softcut input":"Microphone unavailable");
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){
        super.onRequestPermissionsResult(request,permissions,results);
        if(request==MIC_PERMISSION&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)toggleMic();
    }
    private void installDemos(){
        try{
            for(String item:getAssets().list("scripts")){
                File f=new File(scripts,item);if(f.exists())continue;
                try(InputStream in=getAssets().open("scripts/"+item);FileOutputStream out=new FileOutputStream(f)){
                    byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
                }
            }
        }catch(Exception e){android.util.Log.e("NornsPocket","Could not install demo scripts",e);}
    }
    private void installFactoryAudio(){
        File file=new File(audioFolder,"factory_loop.wav");if(file.exists())return;
        try{
            int frames=SoftcutAudio.SR*2;
            float[] mono=new float[frames];
            double[] notes={110,164.81,196,261.63,146.83,220,293.66,329.63};
            for(int i=0;i<frames;i++){
                int step=i/(SoftcutAudio.SR/4);
                float p=(i%(SoftcutAudio.SR/4))/(float)(SoftcutAudio.SR/4);
                double f=notes[Math.min(notes.length-1,step)];
                float envelope=(float)Math.pow(1-p,2)*.45f;
                mono[i]=(float)((Math.sin(2*Math.PI*f*i/SoftcutAudio.SR)+.25*Math.sin(2*Math.PI*f*2*i/SoftcutAudio.SR))*envelope);
            }
            WavIO.write(file,mono,null,0,frames,SoftcutAudio.SR);
        }catch(Exception e){android.util.Log.e("NornsPocket","Factory WAV",e);}
    }
    private File[] scriptFiles(){
        File[] f=scripts.listFiles((dir,name)->name.toLowerCase().endsWith(".lua"));
        if(f==null)return new File[0];Arrays.sort(f,Comparator.comparing(File::getName));return f;
    }
    private void refreshScripts(){
        File[] files=scriptFiles();String[] names=new String[files.length];
        for(int i=0;i<files.length;i++)names[i]=files[i].getName();
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,names);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        picker.setAdapter(adapter);
    }
    private void showStatus(String str){runOnUiThread(()->{if(status!=null)status.setText(str);android.util.Log.d("NornsPocket",str);});}
    @Override public boolean dispatchKeyEvent(KeyEvent e){
        if(lua==null)return super.dispatchKeyEvent(e);
        boolean down=e.getAction()==KeyEvent.ACTION_DOWN;
        if(e.getRepeatCount()>0&&down)return true;
        int key=e.getKeyCode();int button=0,encoder=0,delta=0;
        if(key==KeyEvent.KEYCODE_F1)button=1;
        else if(key==KeyEvent.KEYCODE_F2)button=2;
        else if(key==KeyEvent.KEYCODE_F3)button=3;
        else if(key==KeyEvent.KEYCODE_Q){encoder=1;delta=1;}
        else if(key==KeyEvent.KEYCODE_A){encoder=1;delta=-1;}
        else if(key==KeyEvent.KEYCODE_W){encoder=2;delta=1;}
        else if(key==KeyEvent.KEYCODE_S){encoder=2;delta=-1;}
        else if(key==KeyEvent.KEYCODE_E){encoder=3;delta=1;}
        else if(key==KeyEvent.KEYCODE_D){encoder=3;delta=-1;}
        else if(key==KeyEvent.KEYCODE_G){if(down&&pageButton!=null)pageButton.performClick();return true;}
        if(button!=0){lua.key(button,down?1:0);return true;}
        if(encoder!=0){if(down)lua.enc(encoder,delta);return true;}
        return super.dispatchKeyEvent(e);
    }
    @Override protected void onDestroy(){
        if(lua!=null)lua.close();if(monome!=null)monome.destroy();if(midi!=null)midi.close();
        if(osc!=null)osc.stop();if(audio!=null)audio.stop();super.onDestroy();
    }

    private final class DisplayView extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        DisplayView(){super(MainActivity.this);setBackground(shape(PANEL,0xFF394649));}
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas);
            int padding=dp(12);float availW=getWidth()-2f*padding,availH=getHeight()-2f*padding;
            float scale=Math.min(availW/128f,availH/64f);
            float w=128*scale,h=64*scale,left=(getWidth()-w)/2f,top=(getHeight()-h)/2f;
            p.setColor(Color.BLACK);canvas.drawRoundRect(new RectF(left-3,top-3,left+w+3,top+h+3),dp(4),dp(4),p);
            Bitmap b=screen.image();synchronized(screen){
                p.setFilterBitmap(false);p.setColor(Color.WHITE);
                canvas.drawBitmap(b,new Rect(0,0,128,64),new RectF(left,top,left+w,top+h),p);
            }
        }
    }
    private final class EncoderView extends View {
        final int n;float lastY,lastX;int total=0;final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        EncoderView(int n){super(MainActivity.this);this.n=n;setBackground(shape(PANEL,0xFF29383C));setPadding(dp(5),dp(5),dp(5),dp(5));}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);float cx=getWidth()/2f,cy=getHeight()*.49f,rad=Math.min(getWidth(),getHeight())*.30f;
            p.setStyle(Paint.Style.FILL);p.setColor(0xFF303E43);c.drawCircle(cx,cy,rad+dp(4),p);
            p.setColor(0xFF63797B);c.drawCircle(cx,cy,rad,p);
            p.setColor(0xFF172023);c.drawCircle(cx,cy,rad-dp(4),p);
            float angle=(float)(-Math.PI*.7+(total%32)/32f*Math.PI*1.4);
            p.setColor(ACCENT);p.setStrokeWidth(dp(3));p.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(cx,cy,cx+(float)Math.sin(angle)*rad*.78f,cy-(float)Math.cos(angle)*rad*.78f,p);
            p.setTypeface(Typeface.create("monospace",Typeface.BOLD));p.setTextSize(dp(11));p.setTextAlign(Paint.Align.CENTER);
            c.drawText("E"+n,cx,getHeight()-dp(7),p);
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:lastY=e.getY();lastX=e.getX();return true;
                case MotionEvent.ACTION_MOVE:
                    float dy=lastY-e.getY(),dx=e.getX()-lastX;
                    int delta=(int)((dy+dx)/dp(8));
                    if(delta!=0){total+=delta;lua.enc(n,delta);lastY=e.getY();lastX=e.getX();invalidate();}return true;
                case MotionEvent.ACTION_UP:performClick();return true;
            }
            return true;
        }
        @Override public boolean performClick(){super.performClick();return true;}
    }
    private final class GridView extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        GridView(){super(MainActivity.this);setBackground(shape(PANEL,0xFF394649));}
        @Override protected void onDraw(Canvas c){super.onDraw(c);
            float margin=dp(8),width=getWidth()-2*margin,height=getHeight()-2*margin;
            float step=Math.min(width/16f,height/8f);
            float x0=(getWidth()-step*16)/2,y0=(getHeight()-step*8)/2;
            for(int y=0;y<8;y++)for(int x=0;x<16;x++){
                float cx=x0+(x+.5f)*step,cy=y0+(y+.5f)*step;
                p.setColor(x/8==grid.page?0xFF293B3D:0xFF182729);
                c.drawRoundRect(new RectF(cx-step*.44f,cy-step*.44f,cx+step*.44f,cy+step*.44f),dp(3),dp(3),p);
                int l=grid.get(x,y);
                int intensity=(int)(24+l*14.7f);
                p.setColor(Color.rgb(Math.min(255,intensity),Math.min(255,(int)(intensity*.85)),Math.min(255,(int)(intensity*.55))));
                if(l==0)p.setColor(x/8==grid.page?0xFF4A6063:0xFF334448);
                c.drawRoundRect(new RectF(cx-step*.34f,cy-step*.34f,cx+step*.34f,cy+step*.34f),dp(2),dp(2),p);
            }
        }
        @Override public boolean onTouchEvent(MotionEvent e){
            int action=e.getActionMasked();if(action!=MotionEvent.ACTION_DOWN&&action!=MotionEvent.ACTION_UP&&action!=MotionEvent.ACTION_CANCEL)return true;
            float margin=dp(8),step=Math.min((getWidth()-2f*margin)/16f,(getHeight()-2f*margin)/8f);
            float x0=(getWidth()-step*16)/2,y0=(getHeight()-step*8)/2;
            int x=(int)((e.getX()-x0)/step),y=(int)((e.getY()-y0)/step);
            if(x>=0&&x<16&&y>=0&&y<8)lua.gridKey(x+1,y+1,action==MotionEvent.ACTION_DOWN?1:0);
            return true;
        }
    }
}
