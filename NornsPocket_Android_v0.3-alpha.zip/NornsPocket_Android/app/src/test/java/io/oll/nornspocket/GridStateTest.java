package io.oll.nornspocket;

import org.junit.Test;
import static org.junit.Assert.*;

public class GridStateTest {
    @Test public void seriesFrameHasOneHeaderAndEightRows(){
        GridState g=new GridState();g.set(1,1,15);g.set(8,1,1);
        byte[] frame=g.seriesFrame();assertEquals(9,frame.length);
        assertEquals(0x80,frame[0]&255);assertEquals(0x81,frame[1]&255);
        g.threshold=8;assertEquals(0x01,g.seriesFrame()[1]&255);
    }
    @Test public void pagingMapsSixteenColumnsToPhysicalEight(){
        GridState g=new GridState();g.set(9,1,15);
        assertEquals(0,g.seriesFrame()[1]);
        g.page=1;assertEquals(1,g.seriesFrame()[1]);
        assertEquals(8,g.mapPhysical(0,0)[0]);
    }
}
