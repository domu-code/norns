package io.oll.nornspocket;

import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public class MidiStreamParserTest {
    @Test public void runningStatusAndRealtime() {
        MidiStreamParser p=new MidiStreamParser();
        List<byte[]> msgs=p.feed(new byte[]{(byte)0x90,60,100,(byte)0xF8,62,90});
        assertEquals(3,msgs.size());
        assertArrayEquals(new byte[]{(byte)0x90,60,100},msgs.get(0));
        assertArrayEquals(new byte[]{(byte)0xF8},msgs.get(1));
        assertArrayEquals(new byte[]{(byte)0x90,62,90},msgs.get(2));
    }
    @Test public void splitAcrossChunks() {
        MidiStreamParser p=new MidiStreamParser();
        assertTrue(p.feed(new byte[]{(byte)0xB0,1}).isEmpty());
        List<byte[]> msgs=p.feed(new byte[]{64});
        assertEquals(1,msgs.size());assertArrayEquals(new byte[]{(byte)0xB0,1,64},msgs.get(0));
    }
}
