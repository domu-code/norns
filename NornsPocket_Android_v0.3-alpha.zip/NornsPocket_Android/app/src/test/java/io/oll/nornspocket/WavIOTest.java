package io.oll.nornspocket;

import org.junit.Test;
import static org.junit.Assert.*;
import java.io.File;

public class WavIOTest {
    @Test public void pcm16MonoRoundtrip() throws Exception {
        File f=File.createTempFile("norns-wave-",".wav");
        try {
            float[] samples={-1f,-.5f,0f,.5f,1f};
            WavIO.write(f,samples,null,0,samples.length,48000);
            WavIO.Data d=WavIO.read(f);
            assertEquals(48000,d.rate);assertEquals(1,d.channels.length);assertEquals(5,d.frames());
            for(int i=0;i<5;i++)assertEquals(samples[i],d.channels[0][i],.0001f);
        } finally {f.delete();}
    }
    @Test public void pcm16StereoRoundtrip() throws Exception {
        File f=File.createTempFile("norns-wave-",".wav");
        try {
            WavIO.write(f,new float[]{.5f,0},new float[]{0,.5f},0,2,44100);
            WavIO.Data d=WavIO.read(f);
            assertEquals(2,d.channels.length);assertEquals(44100,d.rate);
            assertEquals(.5,d.channels[0][0],.0001);assertEquals(.5,d.channels[1][1],.0001);
        }finally{f.delete();}
    }
}
